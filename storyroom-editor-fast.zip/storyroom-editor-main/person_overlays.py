"""Person photo overlays: when the narrator says a name, that person's photo appears.

The photo is laid OVER the picture that is already playing: full screen by default
(the photo fitted to the frame over a blurred copy of itself), or as a corner card. Nothing on the
storyboard changes: no Beat is split, no cut moves, no frame is added or removed, and
the narration is untouched. The card is composited in the final render pass (and drawn
over the monitor in the preview), so turning overlays off gives back exactly the film
that was there before.

Rules
  * Timing `cue` (default): the photo is up for the whole SRT line that names the
    person, and through following lines that name them again. When one line names two
    people, the first holds until the second name is spoken, then the second takes over.
    Timing `fixed`: the photo arrives a moment before the word and stays for `hold_ms`.
  * Saying the same name again while the card is up keeps it up instead of flashing it
    off and on, up to `max_ms` in one stretch.
  * Only one card is on screen at a time. When the narrator moves on to another person
    the first card gives way to the second.
  * A card never crosses into a sound bite: sound bites show their speaker. A card that
    would have less than `min_ms` before a bite starts is left out and reported.
  * A person with no uploaded photo, or switched off, is reported and never shown.

Where a name falls inside an SRT cue is estimated from its position in the cue text.
SRT cues are a few seconds long, so this lands within a fraction of a second; the
preview shows the result so it can be checked by eye.

This module decides timing and draws the card. It does not verify who is in a photo,
where the photo came from or whether it may be published -- that is the uploader's
own responsibility and is recorded as such.
"""
from pathlib import Path
import hashlib
import re
import uuid

PHOTO_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.webp')

DEFAULTS = {
    'enabled': True,
    'style': 'full',          # full (photo fills the screen) | card (corner card)
    'timing': 'cue',          # cue (whole SRT line) | fixed (hold_ms after the name)
    'position': 'right',      # right | left | center
    'size': 'medium',         # small | medium | large
    'show_label': True,       # name and role under the photo
    'hold_ms': 3500,          # how long one mention keeps the card up
    'max_ms': 8000,           # longest one card stays up in one stretch
    'merge_gap_ms': 1500,     # same name again within this keeps the card up
    'lead_ms': 150,           # card arrives this long before the word
    'min_ms': 1500,           # shorter than this reads as a flash, so it is left out
    'fade_ms': 250,           # fade in and out
    'with_visual_plan': False,  # also show cards when an applied visual plan already shows the photos
}
POSITIONS = ('right', 'left', 'center')
STYLES = ('full', 'card')
TIMINGS = ('cue', 'fixed')
# Between two photos of different people, footage showing for less than this would
# read as a flash, so the first photo is held until the second arrives.
BRIDGE_MS = 800
SIZES = {'small': 0.36, 'medium': 0.46, 'large': 0.58}   # photo height / frame height
LIMITS = {'hold_ms': (1000, 15000), 'max_ms': (2000, 30000), 'merge_gap_ms': (0, 10000),
          'lead_ms': (0, 1000), 'min_ms': (300, 5000), 'fade_ms': (0, 1000)}
# Short words that are names in nobody's case but often begin or end a full name.
_NOT_A_NAME = {'the', 'and', 'van', 'von', 'der', 'jr', 'sr', 'iii', 'mr', 'mrs', 'ms', 'dr'}
# A lone first name or surname followed by one of these is a place or an organisation
# ("Harris County", "Thompson Street"), not the person.
_PLACE_WORDS = ('County', 'Street', 'St', 'Avenue', 'Ave', 'Road', 'Rd', 'Boulevard', 'Blvd', 'Drive', 'Lane',
                'Park', 'Bayou', 'River', 'Creek', 'Lake', 'City', 'Town', 'Township', 'Parish', 'Department',
                'University', 'College', 'School', 'Elementary', 'High', 'Hospital', 'Center', 'Centre', 'Church',
                'Apartments', 'Mall', 'Bridge', 'Highway', 'Freeway', 'Station', 'Airport', 'Courthouse')


# ----------------------------------------------------------------------------- settings

def settings(project):
    """The project's overlay settings with defaults filled in and values bounded."""
    saved = project.get('person_overlay_settings') or {}
    result = dict(DEFAULTS)
    for key, value in saved.items():
        if key not in DEFAULTS:
            continue
        if key in ('enabled', 'show_label', 'with_visual_plan'):
            result[key] = bool(value)
        elif key == 'position':
            result[key] = value if value in POSITIONS else DEFAULTS['position']
        elif key == 'size':
            result[key] = value if value in SIZES else DEFAULTS['size']
        elif key == 'style':
            result[key] = value if value in STYLES else DEFAULTS['style']
        elif key == 'timing':
            result[key] = value if value in TIMINGS else DEFAULTS['timing']
        else:
            try:
                low, high = LIMITS[key]
                result[key] = int(min(high, max(low, int(value))))
            except (TypeError, ValueError):
                pass
    return result


def clean_settings(data):
    """Validate a settings update from the client. Raises ValueError with a reason."""
    if not isinstance(data, dict):
        raise ValueError('Overlay settings must be an object.')
    out = {}
    for key, value in data.items():
        if key not in DEFAULTS:
            raise ValueError(f'Unknown overlay setting: {key}.')
        if key in ('enabled', 'show_label', 'with_visual_plan'):
            out[key] = bool(value)
        elif key == 'position':
            if value not in POSITIONS:
                raise ValueError('Card position must be right, left or center.')
            out[key] = value
        elif key == 'size':
            if value not in SIZES:
                raise ValueError('Card size must be small, medium or large.')
            out[key] = value
        elif key == 'style':
            if value not in STYLES:
                raise ValueError('Photo style must be full or card.')
            out[key] = value
        elif key == 'timing':
            if value not in TIMINGS:
                raise ValueError('Photo timing must be cue (whole SRT line) or fixed.')
            out[key] = value
        else:
            low, high = LIMITS[key]
            if type(value) not in (int, float) or not low <= value <= high:
                raise ValueError(f'{key} must be between {low} and {high} milliseconds.')
            out[key] = int(value)
    return out


# ----------------------------------------------------------------------------- people

def new_person_id():
    return uuid.uuid4().hex[:12]


def ensure_ids(people):
    """Give every person a stable id (older projects stored only name/role/aliases)."""
    for person in people:
        if not person.get('id'):
            person['id'] = new_person_id()
    return people


def has_photo(person, root):
    photo = person.get('photo') or {}
    return bool(photo.get('path')) and (Path(root) / photo['path']).is_file()


def _tokens(name):
    return [t for t in re.findall(r"[A-Za-z][A-Za-z'\-]*", name or '')]


def _terms(person, people):
    """(term, short) pairs. `short` marks a lone first name or surname added automatically."""
    terms = [(person.get('name', ''), False)] + [(a, False) for a in person.get('aliases') or []]
    if person.get('short_names', True):
        others = set()
        for other in people:
            if other is person:
                continue
            for word in _tokens(other.get('name', '')) + [w for a in other.get('aliases') or [] for w in _tokens(a)]:
                others.add(word.casefold())
        words = _tokens(person.get('name', ''))
        if len(words) > 1:
            for word in (words[0], words[-1]):
                if len(word) >= 3 and word.casefold() not in _NOT_A_NAME and word.casefold() not in others:
                    terms.append((word, True))
    seen, result = set(), []
    for term, short in terms:
        term = ' '.join(term.split())
        if term and term.casefold() not in seen:
            seen.add(term.casefold())
            result.append((term, short))
    return result


def terms_for(person, people):
    """Every spelling that counts as saying this person's name.

    The full name and the aliases always count, in any letter case. With
    `short_names` on (the default) the first name and the surname count too, but
    only when written as a name (capital first letter), not followed by a place word
    ("Harris County"), and only when no other person in this production shares that
    word -- so "Bass" never decides between Maliyah Bass and Octavius Bass. Add the
    misspellings the SRT uses ("Malia", "Irvin") as aliases, and phrases that are not
    this person ("Harris County") under `exclude`.
    """
    return [term for term, _ in _terms(person, people)]


def _matcher(people):
    """One regex for every term of every person, longest first, plus a lookup."""
    lookup, short, parts = {}, set(), []
    for person in people:
        for term, is_short in _terms(person, people):
            key = ' '.join(term.casefold().split())
            # A term two people claim (both list "Bass" as an alias) names neither.
            if key in lookup and lookup[key] is not person:
                lookup[key] = None
                continue
            lookup[key] = person
            if is_short:
                short.add(key)
            parts.append(term)
    parts = sorted(set(parts), key=lambda t: (-len(t), t))
    if not parts:
        return None, lookup, short
    body = '|'.join(r'\s+'.join(re.escape(w) for w in term.split()) for term in parts)
    return re.compile(r"(?<![\w])(?:" + body + r")(?![\w])", re.I), lookup, short


_PLACE_AFTER = re.compile(r"\s+(?:" + '|'.join(_PLACE_WORDS) + r")\b")


def _excluded(person, text, start, end):
    """True when the match sits inside a phrase the user said is not this person."""
    for phrase in person.get('exclude') or []:
        phrase = ' '.join(str(phrase).split())
        if not phrase:
            continue
        pattern = r'\s+'.join(re.escape(w) for w in phrase.split())
        for hit in re.finditer(pattern, text, re.I):
            if hit.start() <= start and end <= hit.end():
                return True
    return False


def find_mentions(blocks, people):
    """Each time a person's name is spoken, on the narration clock (ms)."""
    regex, lookup, short = _matcher(people)
    found = []
    if regex is None:
        return found
    for block in blocks:
        text = block.get('text') or ''
        if not text:
            continue
        start, end = int(block['start_ms']), int(block['end_ms'])
        for match in regex.finditer(text):
            key = ' '.join(match.group(0).casefold().split())
            person = lookup.get(key)
            if person is None:
                continue
            if key in short and (not match.group(0)[0].isupper() or _PLACE_AFTER.match(text, match.end())):
                continue
            if _excluded(person, text, match.start(), match.end()):
                continue
            # Place the word by its position in the cue: the cue's words are spread
            # over its duration, so a name halfway through is said about halfway in.
            at = start + round((end - start) * match.start() / max(1, len(text)))
            found.append({'person_id': person['id'], 'name': person.get('name', ''),
                          'cue': block.get('number'), 'narration_ms': at,
                          'said': match.group(0), 'text': text})
    found.sort(key=lambda m: m['narration_ms'])
    return found


# ----------------------------------------------------------------------------- clocks

def narration_segments(project, sound_plan):
    """Narration segments on both clocks, in ms. Bites sit in the gaps between them."""
    from documentary import build_timeline
    timeline = build_timeline(project, sound_plan or {'version': 1, 'revision': 0, 'bites': []})
    result = []
    for seg in timeline['segments']:
        if seg['kind'] != 'narration':
            continue
        result.append({'narration_in': round(seg['source_in_s'] * 1000), 'narration_out': round(seg['source_out_s'] * 1000),
                       'master_in': round(seg['timeline_in_s'] * 1000), 'master_out': round(seg['timeline_out_s'] * 1000)})
    return result, round(timeline['duration_s'] * 1000)


def to_master(segments, narration_ms):
    """(master ms, segment) for a narration moment, or (None, None) outside narration."""
    for seg in segments:
        if seg['narration_in'] <= narration_ms < seg['narration_out']:
            return seg['master_in'] + (narration_ms - seg['narration_in']), seg
    return None, None


# ----------------------------------------------------------------------------- plan

def _cue_windows(mentions, blocks, segments, conf, notes):
    """Whole-SRT-line timing: each line that names someone shows them for the whole line.

    Works on the narration clock first (lines, and where inside a line a second name
    starts), then moves every piece onto the master clock, splitting it at a sound
    bite so a photo never covers one.
    """
    cues = {b['number']: b for b in blocks}
    by_cue = {}
    for m in mentions:
        by_cue.setdefault(m['cue'], []).append(m)
    pieces = []
    for number in sorted(by_cue, key=lambda n: cues[n]['start_ms']):
        block = cues[number]
        order = []
        for m in sorted(by_cue[number], key=lambda m: m['narration_ms']):
            if order and order[-1]['person_id'] == m['person_id']:
                order[-1]['mentions'] += 1
                continue
            order.append(dict(m, mentions=1))
        line = []
        for i, m in enumerate(order):
            # The first person named holds the line from its start; anyone named later
            # in the same line takes over a moment before their name.
            start = block['start_ms'] if i == 0 else max(block['start_ms'], m['narration_ms'] - conf['lead_ms'])
            end = block['end_ms'] if i == len(order) - 1 else max(block['start_ms'], order[i+1]['narration_ms'] - conf['lead_ms'])
            line.append({'person_id': m['person_id'], 'name': m['name'], 'a': start, 'z': end,
                         'cue': number, 'said': m['said'], 'mentions': m['mentions']})
        # Someone named only in passing ("Malia's father Octavius Bass") would flash.
        # Their share of the line goes to the person next to them in the same line.
        while len(line) > 1:
            short = [i for i, piece in enumerate(line) if piece['z'] - piece['a'] < conf['min_ms']]
            if not short:
                break
            i = short[0]
            piece = line.pop(i)
            other = line[i] if i < len(line) else line[i-1]
            if i < len(line):
                other['a'] = piece['a']
            else:
                other['z'] = piece['z']
            notes.append(f"{piece['name']} (cue {number}, \"{piece['said']}\"): named only in passing, so this line "
                         f"shows {other['name']} throughout.")
        pieces.extend(line)
    windows = []
    for piece in pieces:
        for seg in segments:
            a, z = max(piece['a'], seg['narration_in']), min(piece['z'], seg['narration_out'])
            if z <= a:
                continue
            window = {'person_id': piece['person_id'], 'name': piece['name'],
                      'start_ms': seg['master_in'] + a - seg['narration_in'], 'end_ms': seg['master_in'] + z - seg['narration_in'],
                      'cues': [piece['cue']], 'said': piece['said'], 'mentions': piece['mentions'],
                      'narration_ms': a, 'seg_out': seg['master_out']}
            previous = windows[-1] if windows else None
            if previous and previous['seg_out'] == window['seg_out']:
                gap = window['start_ms'] - previous['end_ms']
                if previous['person_id'] == window['person_id'] and gap <= conf['merge_gap_ms']:
                    # The same person named again in the next line: one continuous photo.
                    previous['end_ms'] = max(previous['end_ms'], window['end_ms'])
                    previous['mentions'] += window['mentions']
                    if piece['cue'] not in previous['cues']:
                        previous['cues'].append(piece['cue'])
                    continue
                if 0 <= gap < BRIDGE_MS:
                    previous['end_ms'] = window['start_ms']
            windows.append(window)
    kept = []
    for i, window in enumerate(windows):
        following = windows[i+1] if i + 1 < len(windows) else None
        if window['end_ms'] - window['start_ms'] < conf['min_ms']:
            # A very short line ("Sahara Irvin,") followed by narration that names no
            # one: let the photo run on into it, long enough to be seen.
            limit = min(window['seg_out'], following['start_ms'] if following else window['seg_out'])
            window['end_ms'] = max(window['end_ms'], min(window['start_ms'] + conf['min_ms'], limit))
        length = window['end_ms'] - window['start_ms']
        if length < conf['min_ms']:
            why = ('the next photo' if following and following['start_ms'] <= window['end_ms']
                   else 'a sound bite' if window['end_ms'] == window['seg_out'] else 'footage returns')
            notes.append(f"{window['name']} (cue {window['cues'][0]}, \"{window['said']}\"): left out, the line gives "
                         f"only {length/1000:.1f}s before {why}.")
            continue
        kept.append(window)
    return kept



def plan(project, root, sound_plan=None):
    """Every card window on the final timeline, plus what was left out and why."""
    conf = settings(project)
    people = ensure_ids(list(project.get('people') or []))
    blocks = (project.get('srt') or {}).get('blocks') or []
    summary = {p['id']: {'id': p['id'], 'name': p.get('name', ''), 'role': p.get('role', ''),
                         'terms': terms_for(p, people), 'has_photo': has_photo(p, root),
                         'show': p.get('show', True) is not False, 'mentions': 0, 'windows': 0, 'on_screen_ms': 0}
               for p in people}
    result = {'settings': conf, 'windows': [], 'notes': [], 'people': list(summary.values()),
              'mentions': 0, 'on_screen_ms': 0, 'duration_ms': 0}
    if not people or not blocks:
        return result
    if project.get('visual_plan_applied') and not conf['with_visual_plan']:
        # The applied visual plan already puts each named person's photo (or footage of
        # them) on screen; a card on top would show the same face twice.
        result['notes'].append('A visual plan is in use and already shows the photos, so name cards are off. '
                               'Tick "Also show name cards with the visual plan" to show them as well.')
        result['visual_plan'] = True
        return result
    if not (project.get('voiceover') or {}).get('duration'):
        result['notes'].append('Upload the narration so name mentions can be placed on the timeline.')
        return result
    if sound_plan is None:
        from documentary import load_plan
        sound_plan = load_plan(root)
    segments, duration = narration_segments(project, sound_plan)
    result['duration_ms'] = duration
    mentions = find_mentions(blocks, people)
    result['mentions'] = len(mentions)
    shown, windows, eligible = [], [], []
    for m in mentions:
        info = summary[m['person_id']]
        info['mentions'] += 1
        if not info['has_photo'] or not info['show']:
            continue
        eligible.append(m)
        master, seg = to_master(segments, m['narration_ms'])
        if master is None:
            continue
        shown.append(dict(m, master_ms=master, seg_in=seg['master_in'], seg_out=seg['master_out']))
    if conf['timing'] == 'cue':
        windows = _cue_windows(eligible, blocks, segments, conf, result['notes'])
        shown = []
    current = None

    def close(window, reason=None):
        if window['end_ms'] - window['start_ms'] < conf['min_ms']:
            windows.remove(window)
            result['notes'].append(
                f"{window['name']} (cue {window['cues'][0]}, \"{window['said']}\"): left out, only "
                f"{(window['end_ms']-window['start_ms'])/1000:.1f}s before {reason or 'the next card'}.")

    for m in shown:
        start = max(m['seg_in'], m['master_ms'] - conf['lead_ms'])
        end = min(m['seg_out'], m['master_ms'] + conf['hold_ms'])
        if current and current['person_id'] == m['person_id'] and current['seg_out'] == m['seg_out'] \
                and start <= current['end_ms'] + conf['merge_gap_ms']:
            # Same person again, close by: keep the card up rather than flash it.
            current['end_ms'] = min(max(current['end_ms'], end), current['start_ms'] + conf['max_ms'], m['seg_out'])
            current['mentions'] += 1
            if m['cue'] not in current['cues']:
                current['cues'].append(m['cue'])
            continue
        if current and start < current['end_ms']:
            # Someone else is named while a card is up: the new name takes over.
            current['end_ms'] = start
            close(current, f"{m['name']} is named")
        current = {'person_id': m['person_id'], 'name': m['name'], 'start_ms': start, 'end_ms': end,
                   'cues': [m['cue']], 'said': m['said'], 'mentions': 1, 'seg_out': m['seg_out'],
                   'narration_ms': m['narration_ms']}
        windows.append(current)
        if end - start < conf['min_ms']:
            close(current, 'a sound bite starts' if end == m['seg_out'] else None)
            current = None
    for w in windows:
        w.pop('seg_out', None)
        info = summary[w['person_id']]
        info['windows'] += 1
        info['on_screen_ms'] += w['end_ms'] - w['start_ms']
    result['windows'] = windows
    result['on_screen_ms'] = sum(w['end_ms'] - w['start_ms'] for w in windows)
    for info in summary.values():
        if info['mentions'] and not info['has_photo']:
            result['notes'].append(f"{info['name']} is named {info['mentions']} time(s) but has no photo yet.")
        elif info['mentions'] and not info['show']:
            result['notes'].append(f"{info['name']} is switched off, so {info['mentions']} mention(s) show no card.")
        elif not info['mentions']:
            result['notes'].append(f"{info['name']} is never named in the SRT. Add the spelling the SRT uses as an alias "
                                   f"(it currently matches: {', '.join(info['terms']) or 'nothing'}).")
    return result


# ----------------------------------------------------------------------------- card

def _font(size, bold):
    from PIL import ImageFont
    names = (['DejaVuSans-Bold.ttf', 'arialbd.ttf', 'Arial Bold.ttf', 'LiberationSans-Bold.ttf'] if bold
             else ['DejaVuSans.ttf', 'arial.ttf', 'Arial.ttf', 'LiberationSans-Regular.ttf'])
    folders = ['', '/usr/share/fonts/truetype/dejavu/', '/usr/share/fonts/truetype/liberation/',
               'C:/Windows/Fonts/', '/Library/Fonts/', '/System/Library/Fonts/Supplemental/']
    for folder in folders:
        for name in names:
            try:
                return ImageFont.truetype(folder + name, size)
            except OSError:
                continue
    try:
        return ImageFont.load_default(size)
    except TypeError:
        return ImageFont.load_default()


def geometry(width, height, conf):
    """Card size and position on a width x height frame, in pixels."""
    if conf.get('style') == 'full':
        return {'card_w': width, 'card_h': height, 'canvas_w': width, 'canvas_h': height, 'x': 0, 'y': 0,
                'label_h': 0, 'shadow': 0, 'border': 0, 'photo_w': width, 'photo_h': height}
    photo_h = SIZES[conf['size']] * height
    photo_w = photo_h * 0.8
    if photo_w > 0.42 * width:            # tall frames: bound by width instead
        photo_w = 0.42 * width
        photo_h = photo_w / 0.8
    photo_w, photo_h = round(photo_w), round(photo_h)
    border = max(3, round(photo_h * 0.012))
    label_h = round(photo_h * 0.19) if conf['show_label'] else 0
    shadow = max(6, round(photo_h * 0.035))
    card_w = photo_w + 2 * border
    card_h = photo_h + 2 * border + label_h
    canvas_w, canvas_h = card_w + 2 * shadow, card_h + 2 * shadow
    margin = round(0.05 * width)
    if conf['position'] == 'left':
        x = margin
    elif conf['position'] == 'center':
        x = (width - card_w) // 2
    else:
        x = width - margin - card_w
    # Vertically a little above centre: clear of top captions and bottom subtitles.
    y = max(round(0.06 * height), round((height - card_h) / 2 - 0.03 * height))
    return {'photo_w': photo_w, 'photo_h': photo_h, 'border': border, 'label_h': label_h, 'shadow': shadow,
            'card_w': card_w, 'card_h': card_h, 'canvas_w': canvas_w, 'canvas_h': canvas_h,
            # Where the canvas (card plus its shadow) goes on the frame.
            'x': x - shadow, 'y': y - shadow}


def _label_lines(draw, name, role, room, height_px):
    lines = [(name.upper(), True, 0.36, (255, 255, 255, 255))]
    if role:
        lines.append((role, False, 0.25, (235, 190, 70, 255)))
    sized = []
    for text, bold, share, colour in lines:
        size = max(8, round(height_px * share))
        font = _font(size, bold)
        while size > 8 and draw.textlength(text, font=font) > room:
            size -= 1
            font = _font(size, bold)
        sized.append((text, font, colour, draw.textbbox((0, 0), text, font=font)))
    return sized


def draw_full(photo_path, name, role, width, height, conf, focus_y=0.3):
    """The photo filling the frame: fitted whole over a blurred copy of itself.

    A photo the shape of the frame simply fills it. Any other shape is shown whole,
    never stretched or cropped, with a soft blurred fill behind it -- the way news
    graphics show a portrait in a wide frame.
    """
    from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageOps
    with Image.open(photo_path) as source:
        photo = ImageOps.exif_transpose(source).convert('RGB')
    w, h = photo.size
    frame = Image.new('RGB', (width, height), (0, 0, 0))
    if abs((w / h) / (width / height) - 1) <= 0.03:
        frame = photo.resize((width, height), Image.LANCZOS)
    else:
        cover = max(width / w, height / h)
        back = photo.resize((max(1, round(w * cover)), max(1, round(h * cover))), Image.LANCZOS)
        left, top = (back.width - width) // 2, round((back.height - height) * max(0.0, min(1.0, focus_y)))
        back = back.crop((left, top, left + width, top + height))
        back = back.filter(ImageFilter.GaussianBlur(max(8, width // 60)))
        frame = ImageEnhance.Brightness(back).enhance(0.55)
        fit = min(width / w, height / h)
        front = photo.resize((max(1, round(w * fit)), max(1, round(h * fit))), Image.LANCZOS)
        frame.paste(front, ((width - front.width) // 2, (height - front.height) // 2))
    frame = frame.convert('RGBA')
    if conf.get('show_label', True) and name:
        # A lower third, kept above where SRT subtitles sit.
        draw = ImageDraw.Draw(frame, 'RGBA')
        bar_h = round(height * 0.11)
        pad = round(min(width, height) * 0.03)
        sized = _label_lines(draw, name, role, round(width * 0.5), bar_h)
        text_w = max(draw.textlength(t, font=f) for t, f, _, _ in sized)
        top = round(height * 0.70)
        left = round(width * 0.05)
        draw.rectangle((left, top, left + text_w + 2 * pad, top + bar_h), fill=(14, 14, 16, 215))
        draw.rectangle((left, top, left + max(4, pad // 4), top + bar_h), fill=(235, 190, 70, 255))
        gap = round(bar_h * 0.06)
        total = sum(b[3] - b[1] for *_, b in sized) + gap * (len(sized) - 1)
        y = top + (bar_h - total) // 2
        for text, font, colour, box in sized:
            draw.text((left + pad + pad // 3, y - box[1]), text, font=font, fill=colour)
            y += box[3] - box[1] + gap
    return frame, geometry(width, height, conf)


def draw_card(photo_path, name, role, width, height, conf, focus_y=0.3):
    """The card as an RGBA image sized for a width x height frame."""
    from PIL import Image, ImageDraw, ImageFilter, ImageOps
    if conf.get('style') == 'full':
        return draw_full(photo_path, name, role, width, height, conf, focus_y)
    g = geometry(width, height, conf)
    with Image.open(photo_path) as source:
        photo = ImageOps.exif_transpose(source).convert('RGB')
    # Fill a 4:5 portrait. Faces sit in the upper part of most photos, so a tall photo
    # is cropped toward its top rather than its middle.
    target = g['photo_w'] / g['photo_h']
    w, h = photo.size
    if w / h > target:
        new_w = round(h * target)
        left = (w - new_w) // 2
        photo = photo.crop((left, 0, left + new_w, h))
    else:
        new_h = round(w / target)
        top = round((h - new_h) * max(0.0, min(1.0, focus_y)))
        photo = photo.crop((0, top, w, top + new_h))
    photo = photo.resize((g['photo_w'], g['photo_h']), Image.LANCZOS)
    canvas = Image.new('RGBA', (g['canvas_w'], g['canvas_h']), (0, 0, 0, 0))
    s = g['shadow']
    shade = Image.new('L', canvas.size, 0)
    ImageDraw.Draw(shade).rectangle((s, s + s // 3, s + g['card_w'], s + g['card_h'] + s // 3), fill=150)
    shade = shade.filter(ImageFilter.GaussianBlur(s / 2))
    canvas.paste((0, 0, 0, 255), (0, 0), shade)
    card = Image.new('RGBA', (g['card_w'], g['card_h']), (255, 255, 255, 255))
    card.paste(photo, (g['border'], g['border']))
    if g['label_h']:
        draw = ImageDraw.Draw(card)
        top = g['photo_h'] + 2 * g['border']
        draw.rectangle((0, top, g['card_w'], g['card_h']), fill=(18, 18, 20, 255))
        pad = round(g['card_w'] * 0.06)
        room = g['card_w'] - 2 * pad
        sized = _label_lines(draw, name, role, room, g['label_h'])
        gap = round(g['label_h'] * 0.06)
        total = sum(b[3] - b[1] for *_, b in sized) + gap * (len(sized) - 1)
        y = top + (g['label_h'] - total) // 2
        for text, font, colour, box in sized:
            draw.text((pad, y - box[1]), text, font=font, fill=colour)
            y += box[3] - box[1] + gap
    canvas.alpha_composite(card, (s, s))
    return canvas, g


def card_key(person, root, width, height, conf):
    photo = Path(root) / (person.get('photo') or {}).get('path', '')
    stat = photo.stat()
    fields = [person.get('name', ''), person.get('role', ''), str(person.get('focus_y', 0.3)), str(stat.st_size),
              str(stat.st_mtime_ns), str(width), str(height), conf['size'], conf['position'], str(conf['show_label']), conf['style'], 'v2']
    return hashlib.sha256('|'.join(fields).encode()).hexdigest()[:24]


def card_file(person, root, width, height, conf, folder=None):
    """Render (or reuse) the card PNG for this person at this frame size."""
    folder = Path(folder or Path(root) / '.cache' / 'person-cards')
    folder.mkdir(parents=True, exist_ok=True)
    # A full-screen photo is opaque, so it is stored as a JPEG: a fraction of the size
    # of a PNG, and much quicker for the export to read once per frame.
    full = conf.get('style') == 'full'
    out = folder / (card_key(person, root, width, height, conf) + ('.jpg' if full else '.png'))
    if not out.is_file():
        image, _ = draw_card(Path(root) / person['photo']['path'], person.get('name', ''), person.get('role', ''),
                             width, height, conf, float(person.get('focus_y', 0.3)))
        temp = out.with_name(out.stem + '.' + uuid.uuid4().hex[:8] + out.suffix)
        if full:
            image.convert('RGB').save(temp, quality=93)
        else:
            image.save(temp)
        temp.replace(out)
    return out


# ----------------------------------------------------------------------------- render

def covered_spans(project, root, sound_plan):
    """(start_s, end_s) on the final timeline where a full-screen photo hides the footage.

    The script's on-screen captions describe the footage ("Sunset Crossing
    Apartments"), so they are held back while a full-screen photo covers it.
    """
    conf = settings(project)
    if not conf['enabled'] or conf['style'] != 'full':
        return []
    return [(w['start_ms'] / 1000, w['end_ms'] / 1000) for w in plan(project, root, sound_plan)['windows']]


def caption_enable(start_s, end_s, spans):
    """ffmpeg `enable` expression: on from start to end, except under a full-screen photo."""
    expr = f'gte(t,{start_s:.3f})*lt(t,{end_s:.3f})'
    inside = [f'between(t,{a:.3f},{b:.3f})' for a, b in spans if a < end_s and b > start_s]
    return expr + (f"*not({'+'.join(inside)})" if inside else '')



def render_filters(project, root, sound_plan, width, height, rate, work, first_input):
    """ffmpeg inputs and filter chain that put the cards over the finished picture.

    Returns (input_args, filter_steps, count). `filter_steps` are filtergraph pieces
    that read [base] and leave [cards]; with no cards there are none. Every card input
    lasts exactly its window, so the frame count and timing of the film are unchanged.
    """
    conf = settings(project)
    if not conf['enabled']:
        return [], [], 0
    data = plan(project, root, sound_plan)
    people = {p['id']: p for p in project.get('people') or []}
    windows = [w for w in data['windows'] if w['person_id'] in people]
    if not windows:
        return [], [], 0
    inputs, steps, label = [], [], 'base'
    cards = {}
    starts = {w['start_ms'] for w in windows}
    ends = {w['end_ms'] for w in windows}
    for k, w in enumerate(windows):
        person = people[w['person_id']]
        if w['person_id'] not in cards:
            path = card_file(person, root, width, height, conf, Path(work) / 'person-cards')
            cards[w['person_id']] = (path, geometry(width, height, conf))
        path, g = cards[w['person_id']]
        start, end = w['start_ms'] / 1000, w['end_ms'] / 1000
        length = end - start
        fade = min(conf['fade_ms'] / 1000, length / 3)
        inputs += ['-loop', '1', '-framerate', rate, '-t', f'{length:.3f}', '-i', str(path)]
        index = first_input + k
        # Fade only where a photo meets footage. Where one photo hands straight over
        # to the next, a fade would dip to the footage underneath for a few frames.
        fades = ''
        if fade > 0 and w['start_ms'] not in ends:
            fades += f'fade=t=in:st=0:d={fade:.3f}:alpha=1,'
        if fade > 0 and w['end_ms'] not in starts:
            fades += f'fade=t=out:st={length-fade:.3f}:d={fade:.3f}:alpha=1,'
        steps.append(f'[{index}:v]format=rgba,{fades}setpts=PTS-STARTPTS+{start:.3f}/TB[card{k}]')
        nxt = 'cards' if k == len(windows) - 1 else f'over{k}'
        steps.append(f"[{label}][card{k}]overlay=x={g['x']}:y={g['y']}:eof_action=pass:"
                     f"enable='between(t,{start:.3f},{end:.3f})'[{nxt}]")
        label = nxt
    return inputs, steps, len(windows)
