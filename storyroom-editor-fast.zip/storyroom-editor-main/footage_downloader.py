"""YouTube Footage Importer: a Markdown sheet of links in, S01.mp4, S02.mp4 ... out.

Flow
  1. `parse_manifest` reads the uploaded .md sheet: every source ID (SRC-01, Source 2,
     S03 ...) with its YouTube link, in sheet order, plus what is wrong with the sheet
     (a source with no link, a link that is not YouTube, a source ID used twice).
  2. `DownloadJob` downloads each valid source in the background, a few at a time,
     with the chosen provider (yt-dlp by default). Every download goes to a temporary
     folder inside the project, is checked, and only then is handed to the editor's
     own import step, which saves it under the source's filename -- SRC-01 becomes
     S01.mp4 -- never under the YouTube title.
  3. State is written to `downloads/youtube.json` in the project after every change,
     so the page can show progress, a restart can resume, and nothing that failed is
     ever quietly skipped.

The numbering is the sheet's own: SRC-07 is S07.mp4 even when SRC-05 is missing, so
a production script that names S07.mp4 always gets the video the sheet calls SRC-07.

Providers are pluggable (`PROVIDERS`). yt-dlp is the default and the only one needed.
Apify is optional and is used only when configured. Downloading is the user's own
decision: this module records where each file came from but does not decide whether
it may be used.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
PRIVATE_LIBS = APP_DIR / '.cache' / 'yt-dlp'
STATE_NAME = 'youtube.json'

# Download states shown to the user.
WAITING, DOWNLOADING, RETRYING, COMPLETED, FAILED = 'waiting', 'downloading', 'retrying', 'completed', 'failed'
EXISTS, CANCELLED, INTERRUPTED = 'exists', 'cancelled', 'interrupted'
ACTIVE = (DOWNLOADING, RETRYING)
REDO = (FAILED, CANCELLED, INTERRUPTED)

DEFAULT_OPTIONS = {'provider': 'yt-dlp', 'quality': '1080', 'concurrency': 2, 'cookies_from_browser': '',
                   'attempts': 3, 'auto_start': True}
QUALITIES = ('720', '1080', 'best')
BROWSERS = ('', 'chrome', 'edge', 'firefox', 'brave', 'opera', 'safari', 'chromium', 'vivaldi')


# ============================================================================ sheet

_URL = re.compile(r'https?://[^\s<>()\[\]|"\'`]+', re.I)
_ID = re.compile(r'(?<![A-Za-z0-9])(?:SRC|SOURCE|SRCE)[\s\-_#:.]*0*(\d{1,3})(?![0-9])'
                 r'|(?<![A-Za-z0-9])S0*(\d{1,3})(?![0-9A-Za-z])', re.I)
_YT_ID = re.compile(r'^[A-Za-z0-9_-]{11}$')


def youtube_id(url):
    """The 11-character video id of a YouTube link, or None."""
    from urllib.parse import urlparse, parse_qs
    try:
        parts = urlparse(url.strip().rstrip('.,;'))
    except ValueError:
        return None
    host = (parts.hostname or '').lower()
    if host.startswith('www.'):
        host = host[4:]
    if host.startswith('m.'):
        host = host[2:]
    candidate = None
    if host == 'youtu.be':
        candidate = parts.path.strip('/').split('/')[0]
    elif host in ('youtube.com', 'music.youtube.com', 'youtube-nocookie.com'):
        if parts.path == '/watch':
            candidate = (parse_qs(parts.query).get('v') or [''])[0]
        else:
            bits = [b for b in parts.path.split('/') if b]
            if len(bits) >= 2 and bits[0] in ('shorts', 'live', 'embed', 'v', 'e'):
                candidate = bits[1]
    return candidate if candidate and _YT_ID.match(candidate) else None


def filename_for(number, width=2):
    return f'S{number:0{width}d}.mp4'


def _source_number(text):
    """First source ID in a piece of text (URLs removed), as (label, number)."""
    for match in _ID.finditer(text):
        number = int(match.group(1) or match.group(2))
        if number < 1:
            continue
        return match.group(0).strip(), number
    return None


_FILE = re.compile(r'(?<![\w\-.])([\w\-().]+\.(?:mp4|mov))(?![\w])', re.I)


def _identity(text):
    """(label, number, filename) for one line with its links removed, or None.

    A filename written in the sheet ("S01.mp4", "Bayou_drone.mp4") is used exactly as
    written. Otherwise the file is named from the source number: SRC-01 -> S01.mp4.
    """
    files = _FILE.findall(text)
    named = files[0] if files else None
    found = _source_number(_FILE.sub(' ', text))
    if not found and named:
        match = re.fullmatch(r'S0*(\d{1,3})\.(?:mp4|mov)', named, re.I)
        if match and int(match.group(1)) > 0:
            found = (named.rsplit('.', 1)[0], int(match.group(1)))
    if found:
        return found[0], found[1], named
    if named:
        return named, None, named
    return None


def parse_manifest(text):
    """Read a footage sheet. Returns {'entries', 'issues', 'counts'}.

    Accepts the layouts people actually write: a Markdown table (one row per source),
    a list ("- SRC-01: https://..."), or a heading per source followed by its link.
    A row is matched by the source ID (or the filename it gives) and the link on the
    same line; a source on its own line takes the next link below it, before the next
    source.
    """
    entries, issues = [], []
    pending = None                       # (label, number, filename, line) seen without a link yet
    in_fence = False
    lines = (text or '').replace('\r\n', '\n').replace('\r', '\n').split('\n')

    def missing(item):
        issues.append({'kind': 'missing_link', 'line': item[3], 'text': f'{item[0]} (line {item[3]}) has no link.',
                       'number': item[1], 'named': item[2]})

    for line_no, raw in enumerate(lines, 1):
        line = raw.strip()
        if line.startswith('```'):
            in_fence = not in_fence
            continue
        if not line or re.fullmatch(r'\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?', line):
            continue
        urls = _URL.findall(line)
        found = _identity(_URL.sub(' ', line))
        if found and urls:
            if pending:
                missing(pending)
            pending = None
            entries.append({'source_label': found[0], 'number': found[1], 'named': found[2], 'url': urls[0], 'line': line_no})
            for extra in urls[1:]:
                if youtube_id(extra):
                    issues.append({'kind': 'extra_link', 'line': line_no,
                                   'text': f'Line {line_no} has more than one YouTube link; only the first is used for {found[0]}.'})
        elif found:
            if pending:
                missing(pending)
            pending = (found[0], found[1], found[2], line_no)
        elif urls:
            if pending:
                entries.append({'source_label': pending[0], 'number': pending[1], 'named': pending[2], 'url': urls[0],
                                'line': line_no})
                pending = None
            elif any(youtube_id(u) for u in urls):
                issues.append({'kind': 'no_source_id', 'line': line_no,
                               'text': f'Line {line_no} has a YouTube link but no source ID or filename, so it was not '
                                       f'downloaded (the editor does not guess which source it is).'})
    if pending:
        missing(pending)

    numbers = [e['number'] for e in entries if e['number']] + [i['number'] for i in issues if i.get('number')]
    width = 3 if any(n > 99 for n in numbers) else 2

    def name_of(number, named):
        return named or filename_for(number, width)

    def id_of(number, named):
        return f'SRC-{number:0{width}d}' if number else Path(named).stem

    for issue in issues:
        if issue['kind'] == 'missing_link':
            issue['filename'] = name_of(issue['number'], issue['named'])
            issue['source_id'] = id_of(issue['number'], issue['named'])
    seen_files, seen_videos, result = {}, {}, []
    for e in entries:
        vid = youtube_id(e['url'])
        e['source_id'] = id_of(e['number'], e['named'])
        e['filename'] = name_of(e['number'], e['named'])
        e['named_by_sheet'] = bool(e['named'])
        e['video_id'] = vid
        e['valid'] = bool(vid)
        e['problem'] = ''
        key = e['filename'].casefold()
        if not vid:
            e['problem'] = 'Not a YouTube video link.'
            issues.append({'kind': 'invalid_url', 'line': e['line'],
                           'text': f"{e['source_id']} (line {e['line']}): {e['url']} is not a YouTube video link."})
        elif key in seen_files and seen_files[key]['video_id'] == vid:
            # The same file and the same video again (a guide names each source on every
            # card that uses it): one source, not a problem.
            continue
        elif key in seen_files:
            first = seen_files[key]
            e['valid'] = False
            e['problem'] = f"Duplicate of {first['source_id']} on line {first['line']}."
            issues.append({'kind': 'duplicate_source', 'line': e['line'],
                           'text': f"{e['filename']} is given a different video on line {e['line']} than on line "
                                   f"{first['line']}. Only the first is downloaded; check which is right."})
        else:
            seen_files[key] = e
            if vid in seen_videos:
                issues.append({'kind': 'duplicate_link', 'line': e['line'],
                               'text': f"{e['source_id']} is the same video as {seen_videos[vid]['source_id']}. It is "
                                       f"downloaded once and saved as both {seen_videos[vid]['filename']} and {e['filename']}."})
            else:
                seen_videos[vid] = e
        if vid:
            e['url'] = f'https://www.youtube.com/watch?v={vid}'
        result.append(e)
    # A source named without a link is only missing if no line anywhere gives it one.
    linked = {e['filename'].casefold() for e in result}
    seen_missing, kept = set(), []
    for i in issues:
        if i['kind'] == 'missing_link':
            if i['filename'].casefold() in linked or i['filename'].casefold() in seen_missing:
                continue
            seen_missing.add(i['filename'].casefold())
        kept.append(i)
    issues = kept
    present = {e['number'] for e in result if e['number']} | {i['number'] for i in issues if i.get('number')}
    if present:
        absent = [n for n in range(1, max(present) + 1) if n not in present]
        if absent:
            runs, start = [], absent[0]
            for a, b in zip(absent, absent[1:] + [None]):
                if b != a + 1:
                    runs.append(f'S{start:0{width}d}' if start == a else f'S{start:0{width}d}-S{a:0{width}d}')
                    start = b
            issues.append({'kind': 'gap', 'text': f"Not in the sheet: {', '.join(runs)}. Numbering is kept as written, "
                                                  f"so those files will not exist (fine if the script does not use them)."})
    counts = {'sources': len(result), 'valid': sum(e['valid'] for e in result), 'issues': len(issues)}
    return {'entries': result, 'issues': issues, 'counts': counts}


# ============================================================================ providers

class DownloadError(Exception):
    def __init__(self, message, permanent=False):
        super().__init__(message)
        self.permanent = permanent


class Cancelled(Exception):
    pass


# yt-dlp error text -> (plain explanation, worth retrying?)
_KNOWN_ERRORS = [
    (r'private video', 'This video is private.', False),
    (r'video unavailable|this video is not available|has been removed|no longer available', 'This video is unavailable or was removed.', False),
    (r'account associated with this video has been terminated', 'The channel that posted this video was terminated.', False),
    (r'confirm your age|age[- ]restricted|inappropriate for some users',
     'This video is age-restricted. Choose a browser under "Use sign-in from" and retry.', False),
    (r"not a bot|confirm you.re not a bot",
     'YouTube asked for a sign-in check. Choose a browser under "Use sign-in from" and retry.', False),
    (r'members[- ]only|join this channel', 'This video is for channel members only.', False),
    (r'not available in your country|geo.?restrict', 'This video is blocked in your country.', False),
    (r'copyright', 'This video was blocked by a copyright claim.', False),
    (r'live event will begin|premieres in', 'This is a live stream or premiere that has not started.', False),
    (r'unsupported url|incomplete youtube id|is not a valid url', 'The link is not a downloadable video.', False),
    (r'requested format is not available', 'No downloadable format was offered for this video.', False),
    (r'no space left on device|disk full', 'The disk is full.', False),
    (r'http error 429|too many requests', 'YouTube is limiting requests right now.', True),
    (r'timed out|connection reset|temporary failure|name resolution|network is unreachable|http error 5\d\d|'
     r'remote end closed|unable to download|getaddrinfo|ssl', 'Network problem while downloading.', True),
]


def explain(text):
    low = (text or '').lower()
    for pattern, message, retry in _KNOWN_ERRORS:
        if re.search(pattern, low):
            return message, retry
    return (text or 'Download failed.').strip()[:300], True


class YtDlpProvider:
    """yt-dlp, run as a separate process so it can be cancelled and never blocks the app."""
    name = 'yt-dlp'

    @staticmethod
    def command():
        """How to start yt-dlp, or None. Override with STORYROOM_YTDLP_CMD."""
        override = os.environ.get('STORYROOM_YTDLP_CMD', '').strip()
        if override:
            import shlex
            return shlex.split(override, posix=os.name != 'nt'), None
        if (PRIVATE_LIBS / 'yt_dlp').is_dir():
            return [sys.executable, '-m', 'yt_dlp'], str(PRIVATE_LIBS)
        try:
            import importlib.util
            if importlib.util.find_spec('yt_dlp'):
                return [sys.executable, '-m', 'yt_dlp'], None
        except (ImportError, ValueError):
            pass
        found = shutil.which('yt-dlp')
        return ([found], None) if found else (None, None)

    @classmethod
    def _env(cls, extra_path):
        env = dict(os.environ, PYTHONIOENCODING='utf-8', PYTHONUNBUFFERED='1')
        if extra_path:
            env['PYTHONPATH'] = extra_path + (os.pathsep + env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
        return env

    @classmethod
    def status(cls):
        cmd, path = cls.command()
        if not cmd:
            return {'available': False, 'version': None,
                    'detail': 'yt-dlp is not installed. Use "Install yt-dlp" below, or run: pip install yt-dlp'}
        try:
            out = subprocess.run(cmd + ['--version'], capture_output=True, text=True, timeout=60, env=cls._env(path))
            version = (out.stdout or '').strip().splitlines()[-1] if out.returncode == 0 and out.stdout.strip() else None
        except (OSError, subprocess.SubprocessError):
            version = None
        if not version:
            return {'available': False, 'version': None, 'detail': 'yt-dlp was found but did not start. Reinstall it.'}
        return {'available': True, 'version': version, 'detail': ''}

    @staticmethod
    def _format_args(quality):
        # Prefer H.264 video and AAC audio in MP4, which every editor and browser plays.
        # A higher resolution only offered as VP9/AV1 is still merged into an MP4.
        if quality == 'best':
            sort = 'res,vcodec:h264,acodec:m4a,ext:mp4:m4a'
        else:
            sort = f'res:{int(quality)},vcodec:h264,acodec:m4a,ext:mp4:m4a'
        return ['-f', 'bv*+ba/b', '-S', sort, '--merge-output-format', 'mp4', '--remux-video', 'mp4']

    def download(self, entry, work, options, report, cancel):
        """Download one entry into `work`. Returns the finished file's path."""
        cmd, path = self.command()
        if not cmd:
            raise DownloadError('yt-dlp is not installed. Use "Install yt-dlp" in the YouTube Footage Importer.', True)
        import imageio_ffmpeg
        stem = Path(entry['filename']).stem
        args = cmd + ['--newline', '--no-playlist', '--no-colors', '--ignore-config', '--no-mtime', '--progress',
                      '--no-simulate', '--continue', '--retries', '10', '--fragment-retries', '10',
                      '--socket-timeout', '30', '--ffmpeg-location', imageio_ffmpeg.get_ffmpeg_exe(),
                      '-o', str(Path(work) / (stem + '.%(ext)s')),
                      '--print', 'before_dl:SRTITLE %(title)s',
                      '--print', 'before_dl:SRSIZE %(filesize,filesize_approx)s',
                      '--print', 'after_move:SRFILE %(filepath)s',
                      '--progress-template', 'download:SRPROGRESS %(progress.downloaded_bytes)s '
                                             '%(progress.total_bytes,progress.total_bytes_estimate)s %(progress.status)s']
        args += self._format_args(options.get('quality', '1080'))
        if options.get('cookies_from_browser'):
            args += ['--cookies-from-browser', options['cookies_from_browser']]
        args.append(entry['url'])
        flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
        proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8',
                                errors='replace', bufsize=1, env=self._env(path), creationflags=flags,
                                start_new_session=os.name != 'nt')
        cancel.register(proc)
        final, errors, tail = None, [], []
        expected, done_parts, last_total, last_bytes = None, 0, None, 0
        try:
            for line in proc.stdout:
                line = line.rstrip('\n')
                if cancel.is_set():
                    break
                if line.startswith('SRTITLE '):
                    report(title=line[8:].strip())
                elif line.startswith('SRSIZE '):
                    expected = _int(line[7:])
                elif line.startswith('SRPROGRESS '):
                    bits = line.split()
                    got, total = _int(bits[1]) if len(bits) > 1 else None, _int(bits[2]) if len(bits) > 2 else None
                    if got is None:
                        continue
                    # Video and audio arrive as two downloads; keep the count rising.
                    if got < last_bytes and last_total:
                        done_parts += last_total
                    last_bytes, last_total = got, total or last_total
                    overall = done_parts + got
                    whole = expected or ((done_parts + total) if total else None)
                    percent = min(99.0, overall * 100 / whole) if whole else None
                    report(downloaded_bytes=overall, total_bytes=whole, progress=percent, phase='downloading')
                elif line.startswith('SRFILE '):
                    final = line[7:].strip()
                elif line.startswith('[Merger]') or line.startswith('[VideoRemuxer]'):
                    report(phase='merging', progress=99.0)
                elif line.startswith('ERROR:'):
                    errors.append(line[6:].strip())
                elif line.strip():
                    tail = (tail + [line])[-8:]
            proc.wait()
        finally:
            cancel.unregister(proc)
        if cancel.is_set():
            raise Cancelled()
        if proc.returncode != 0 or not final:
            message, retry = explain(' '.join(errors) or ' '.join(tail))
            raise DownloadError(message, permanent=not retry)
        result = Path(final)
        if not result.is_file():
            candidates = sorted(Path(work).glob(stem + '.mp4'))
            if not candidates:
                raise DownloadError('yt-dlp finished but the downloaded file is missing.')
            result = candidates[0]
        return result


class ApifyProvider:
    """Optional: download through an Apify actor. Used only when configured.

    Configure with STORYROOM_APIFY_TOKEN and STORYROOM_APIFY_ACTOR (an actor that takes
    a YouTube URL and returns a direct video download URL in its dataset). The field
    names can be adjusted with STORYROOM_APIFY_INPUT_FIELD (default "url") and
    STORYROOM_APIFY_RESULT_FIELD (default: the first of downloadUrl, videoUrl, url).
    Apify runs are billed by Apify; nothing here runs unless it is configured.
    """
    name = 'apify'

    @staticmethod
    def config():
        return {'token': os.environ.get('STORYROOM_APIFY_TOKEN', '').strip(),
                'actor': os.environ.get('STORYROOM_APIFY_ACTOR', '').strip(),
                'input_field': os.environ.get('STORYROOM_APIFY_INPUT_FIELD', 'url').strip() or 'url',
                'result_field': os.environ.get('STORYROOM_APIFY_RESULT_FIELD', '').strip()}

    @classmethod
    def status(cls):
        conf = cls.config()
        if not conf['token'] or not conf['actor']:
            return {'available': False, 'version': None,
                    'detail': 'Optional. Set STORYROOM_APIFY_TOKEN and STORYROOM_APIFY_ACTOR to enable Apify.'}
        return {'available': True, 'version': conf['actor'], 'detail': ''}

    def download(self, entry, work, options, report, cancel):
        import urllib.request
        conf = self.config()
        if not conf['token'] or not conf['actor']:
            raise DownloadError('Apify is not configured.', True)
        actor = conf['actor'].replace('/', '~')
        api = (f'https://api.apify.com/v2/acts/{actor}/run-sync-get-dataset-items?token={conf["token"]}')
        body = json.dumps({conf['input_field']: entry['url']}).encode()
        request = urllib.request.Request(api, data=body, headers={'Content-Type': 'application/json'})
        try:
            with urllib.request.urlopen(request, timeout=600) as response:
                items = json.loads(response.read().decode('utf-8'))
        except Exception as exc:
            raise DownloadError(f'Apify run failed: {exc}') from exc
        item = items[0] if isinstance(items, list) and items else {}
        fields = [conf['result_field']] if conf['result_field'] else ['downloadUrl', 'videoUrl', 'url']
        link = next((item.get(f) for f in fields if isinstance(item.get(f), str) and item.get(f).startswith('http')), None)
        if not link:
            raise DownloadError('The Apify actor returned no download URL.', True)
        if item.get('title'):
            report(title=str(item['title']))
        target = Path(work) / (Path(entry['filename']).stem + '.download')
        with urllib.request.urlopen(link, timeout=60) as response, open(target, 'wb') as out:
            total = _int(response.headers.get('Content-Length'))
            got = 0
            while True:
                if cancel.is_set():
                    raise Cancelled()
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
                got += len(chunk)
                report(downloaded_bytes=got, total_bytes=total, progress=min(99.0, got * 100 / total) if total else None)
        final = target.with_suffix('.mp4')
        target.replace(final)
        return final


PROVIDERS = {'yt-dlp': YtDlpProvider, 'apify': ApifyProvider}


def _int(value):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


# ============================================================================ script check

_SCRIPT_FILE = re.compile(r'^\s*(?:\*\*)?(?:Full\s+source|Video\s+File|Source\s+file|Footage)(?:\*\*)?\s*:\s*(?:\*\*)?\s*'
                          r'([\w\-().]+\.(?:mp4|mov))', re.I | re.M)


def script_needs(text):
    """{filename: latest Source OUT in seconds (or None)} for every video the script names."""
    needs = {}
    try:
        from documentary_beats import read_beats
        for beat in read_beats(text):
            name = beat['source_file']
            needs[name] = max(needs.get(name) or 0, beat['source_out_ms'] / 1000)
        return needs
    except Exception:
        pass
    for name in _SCRIPT_FILE.findall(text or ''):
        needs.setdefault(name, None)
    return needs


def script_check(state, script_text, assets):
    """Compare the sheet with the production script: names, coverage and length.

    Every file the script names should come from a row of the sheet (or already be in
    the project), and every downloaded file must be long enough for the latest Source
    OUT the script asks of it. Footage is downloaded whole from 0:00, so the script's
    timestamps refer to the file as it is.
    """
    if not script_text:
        return None
    needs = script_needs(script_text)
    if not needs:
        return None
    rows = {r['filename'].casefold(): r for r in (state or {}).get('rows', []) if r.get('valid')}
    files = {str(a.get('original_name') or a.get('name') or '').casefold(): a for a in assets
             if a.get('kind') == 'video' and not a.get('derived_from')}
    missing, short, ready = [], [], []
    for name, out in sorted(needs.items()):
        key = name.casefold()
        asset = files.get(key)
        if not asset and key not in rows:
            missing.append(name)
            continue
        if asset and out and float(asset.get('duration') or 0) + 0.001 < out:
            short.append({'filename': name, 'duration_s': float(asset.get('duration') or 0), 'needs_s': out})
        elif asset:
            ready.append(name)
    unused = [r['filename'] for k, r in rows.items() if k not in {n.casefold() for n in needs}]
    return {'script_files': sorted(needs), 'ready': ready, 'missing': missing, 'short': short, 'unused': unused}


# ============================================================================ install

def install_ytdlp(upgrade=True, log=lambda line: None):
    """Install (or update) yt-dlp into the app's private .cache folder.

    Staged in a temporary folder and swapped in only when pip succeeds, so a failed
    or interrupted install leaves the previous copy working.
    """
    import tempfile
    PRIVATE_LIBS.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='yt-dlp-install-', dir=PRIVATE_LIBS.parent) as tmp:
        stage = Path(tmp) / 'yt-dlp'
        cmd = [sys.executable, '-m', 'pip', 'install', '--disable-pip-version-check', '--target', str(stage)]
        if upgrade:
            cmd.append('--upgrade')
        cmd.append('yt-dlp')
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors='replace')
        for line in proc.stdout:
            log(line.rstrip())
        proc.wait()
        if proc.returncode != 0 or not (stage / 'yt_dlp').is_dir():
            raise RuntimeError('pip could not install yt-dlp. Check the internet connection and try again.')
        old = PRIVATE_LIBS.with_name('yt-dlp.old')
        shutil.rmtree(old, ignore_errors=True)
        if PRIVATE_LIBS.exists():
            PRIVATE_LIBS.replace(old)
        stage.replace(PRIVATE_LIBS)
        shutil.rmtree(old, ignore_errors=True)
    return YtDlpProvider.status()


# ============================================================================ state

def state_path(root):
    return Path(root) / 'downloads' / STATE_NAME


def load_state(root):
    path = state_path(root)
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None


def save_state(root, state):
    path = state_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex[:8] + '.tmp')
    temp.write_text(json.dumps(state, indent=1), encoding='utf-8')
    temp.replace(path)


def new_state(manifest_name, parsed, options):
    rows = []
    for e in parsed['entries']:
        rows.append({'source_id': e['source_id'], 'number': e['number'], 'filename': e['filename'], 'url': e['url'],
                     'named_by_sheet': e.get('named_by_sheet', False),
                     'video_id': e['video_id'], 'line': e['line'], 'valid': e['valid'], 'problem': e['problem'],
                     'title': '', 'status': WAITING if e['valid'] else FAILED, 'progress': 0, 'phase': '',
                     'downloaded_bytes': 0, 'total_bytes': None, 'size': None, 'error': '' if e['valid'] else e['problem'],
                     'attempts': 0, 'asset_id': None, 'replace': False, 'started': None, 'finished': None})
    # A source with no link is still a row, so it can never be missed in the table.
    for issue in parsed['issues']:
        if issue['kind'] == 'missing_link' and not any(r['filename'].casefold() == issue['filename'].casefold() for r in rows):
            rows.append({'source_id': issue['source_id'], 'number': issue['number'],
                         'filename': issue['filename'], 'url': '', 'video_id': None, 'line': issue['line'],
                         'valid': False, 'problem': 'No link in the sheet.', 'title': '', 'status': FAILED, 'progress': 0,
                         'phase': '', 'downloaded_bytes': 0, 'total_bytes': None, 'size': None, 'error': 'No link in the sheet.',
                         'attempts': 0, 'asset_id': None, 'replace': False, 'started': None, 'finished': None})
    rows.sort(key=lambda r: r['line'])
    return {'version': 1, 'id': uuid.uuid4().hex[:12], 'manifest': manifest_name, 'created': time.time(),
            'options': dict(DEFAULT_OPTIONS, **(options or {})), 'issues': parsed['issues'], 'rows': rows,
            'job': {'status': 'ready', 'started': None, 'finished': None, 'message': ''}}


def summary(state):
    rows = [r for r in state['rows'] if r['valid']]
    done = sum(r['status'] in (COMPLETED, EXISTS) for r in rows)
    return {'total': len(rows), 'done': done, 'downloaded': sum(r['status'] == COMPLETED for r in rows),
            'existing': sum(r['status'] == EXISTS for r in rows), 'failed': sum(r['status'] == FAILED for r in rows),
            'active': sum(r['status'] in ACTIVE for r in rows), 'waiting': sum(r['status'] == WAITING for r in rows),
            'stopped': sum(r['status'] in (CANCELLED, INTERRUPTED) for r in rows),
            'invalid': sum(not r['valid'] for r in state['rows'])}


def recover(state):
    """After a restart nothing is downloading any more: say so, and allow a resume."""
    changed = False
    for row in state['rows']:
        if row['status'] in ACTIVE:
            row.update(status=INTERRUPTED, phase='', error='The editor was closed during this download. Resume to continue.')
            changed = True
    if state['job']['status'] in ('running', 'cancelling'):
        state['job'].update(status='interrupted', message='Interrupted. Resume to continue where it stopped.')
        changed = True
    return changed


# ============================================================================ job

class CancelToken:
    def __init__(self):
        self._event = threading.Event()
        self._procs = set()
        self._lock = threading.Lock()

    def is_set(self):
        return self._event.is_set()

    def set(self):
        self._event.set()
        with self._lock:
            for proc in list(self._procs):
                _kill_tree(proc)

    def register(self, proc):
        with self._lock:
            self._procs.add(proc)
            if self._event.is_set():
                _kill_tree(proc)

    def unregister(self, proc):
        with self._lock:
            self._procs.discard(proc)


def _kill_tree(proc):
    """Stop a download and anything it started (ffmpeg merging), on every platform."""
    try:
        import psutil
        parent = psutil.Process(proc.pid)
        for child in parent.children(recursive=True):
            child.kill()
        parent.kill()
        return
    except Exception:
        pass
    try:
        if os.name == 'nt':
            subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
        else:
            os.killpg(proc.pid, 9)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


JOBS = {}
JOBS_LOCK = threading.Lock()


def row_key():
    return uuid.uuid4().hex


def running(pid):
    with JOBS_LOCK:
        job = JOBS.get(pid)
        return bool(job and job.thread.is_alive())


class DownloadJob:
    """Download every waiting row of one project's sheet, then register each file.

    `register(row, path)` is supplied by the app. It imports the finished file into the
    project under row['filename'] and returns the new asset id, raising ValueError with
    a reason the user can act on if the file is not usable.
    `existing(row)` returns 'same' (this video is already imported), 'other' (a
    different file with that name is in the project) or None.
    """

    def __init__(self, pid, root, register, existing, retry_delays=(5, 20), local_copy=None):
        self.pid, self.root = pid, Path(root)
        self.register, self.existing = register, existing
        # local_copy(row) -> (path, title) of a file already in the project downloaded
        # from the same video, so it is copied instead of downloaded a second time.
        self.local_copy = local_copy
        self.video_locks, self.shared, self.titles = {}, {}, {}
        self.share = set()
        self.retry_delays = retry_delays
        self.cancel = CancelToken()
        self.lock = threading.RLock()
        self.state = load_state(self.root)
        self.thread = threading.Thread(target=self.run, daemon=True, name='youtube-download-' + pid)
        self._last_save = 0

    # -- state helpers
    def save(self, force=False):
        now = time.time()
        if force or now - self._last_save > 0.5:
            with self.lock:
                save_state(self.root, self.state)
            self._last_save = now

    def update(self, row, **values):
        with self.lock:
            row.update(values)
        self.save(force='status' in values)

    def start(self):
        with JOBS_LOCK:
            old = JOBS.get(self.pid)
            if old and old.thread.is_alive():
                raise RuntimeError('Downloads are already running for this production.')
            JOBS[self.pid] = self
        self.thread.start()
        return self

    def stop(self):
        with self.lock:
            self.state['job'].update(status='cancelling', message='Stopping downloads...')
        self.save(force=True)
        self.cancel.set()

    # -- work
    def run(self):
        work_root = self.root / 'downloads' / 'tmp'
        work_root.mkdir(parents=True, exist_ok=True)
        options = dict(DEFAULT_OPTIONS, **self.state.get('options', {}))
        with self.lock:
            self.state['job'].update(status='running', started=time.time(), finished=None, message='')
            for row in self.state['rows']:
                if not row['valid'] or row['status'] in (COMPLETED,):
                    continue
                if row['status'] == EXISTS and not row.get('replace'):
                    continue
                kind = self.existing(row)
                if kind == 'same' and not row.get('replace'):
                    row.update(status=COMPLETED, progress=100, phase='', error='', note='Already downloaded into this production.')
                elif kind == 'other' and not row.get('replace'):
                    row.update(status=EXISTS, progress=0, phase='', error='',
                               note=f"{row['filename']} is already in this production. Choose Replace to download over it.")
                elif row['status'] in (WAITING,) + REDO + (EXISTS,):
                    row.update(status=WAITING, progress=0, phase='', error='', attempts=0)
        self.save(force=True)
        queue = [r for r in self.state['rows'] if r['valid'] and r['status'] == WAITING]
        seen = set()
        for r in queue:
            if r.get('video_id') in seen:
                self.share.add(r['video_id'])
            seen.add(r.get('video_id'))
        pool = threading.Semaphore(max(1, min(4, int(options.get('concurrency') or 2))))
        workers = []
        for row in queue:
            if self.cancel.is_set():
                break
            pool.acquire()
            if self.cancel.is_set():
                pool.release()
                break
            thread = threading.Thread(target=self._one, args=(row, options, work_root, pool), daemon=True)
            thread.start()
            workers.append(thread)
        for thread in workers:
            thread.join()
        shutil.rmtree(work_root / 'shared', ignore_errors=True)
        with self.lock:
            if self.cancel.is_set():
                for row in self.state['rows']:
                    if row['status'] in (WAITING,) + ACTIVE:
                        row.update(status=CANCELLED, phase='', error='Stopped before it finished. Resume to continue.')
                self.state['job'].update(status='cancelled', finished=time.time(), message='Downloads stopped.')
            else:
                s = summary(self.state)
                done = 'complete' if not s['failed'] and not s['stopped'] else 'finished_with_failures'
                self.state['job'].update(status=done, finished=time.time(),
                                         message=f"{s['done']}/{s['total']} videos ready." +
                                                 (f" {s['failed']} failed." if s['failed'] else ''))
        self.save(force=True)

    def _one(self, row, options, work_root, pool):
        try:
            self._download_with_retries(row, options, work_root)
        finally:
            pool.release()

    def _video_lock(self, vid):
        with self.lock:
            return self.video_locks.setdefault(vid or row_key(), threading.Lock())

    def _copy_existing(self, row, work):
        """Use a copy of this video if it is already here. True when the row is done."""
        vid = row.get('video_id')
        source, title, origin = self.shared.get(vid), self.titles.get(vid, ''), 'this run'
        if not (source and Path(source).is_file()) and self.local_copy:
            found = self.local_copy(row)
            if found:
                source, title, origin = found[0], found[1], 'the project'
        if not (source and Path(source).is_file()):
            return False
        Path(work).mkdir(parents=True, exist_ok=True)
        target = Path(work) / (Path(row['filename']).stem + '.mp4')
        self.update(row, status=DOWNLOADING, phase='copying', progress=50, title=title or row.get('title', ''),
                    started=time.time(), provider='copy')
        shutil.copyfile(source, target)              # streamed on disk, never read into memory
        size = target.stat().st_size
        self.update(row, phase='checking', progress=99.5)
        asset_id = self.register(row, target)
        self.update(row, status=COMPLETED, progress=100, phase='', error='', asset_id=asset_id, finished=time.time(),
                    size=size, replace=False, note=f'Same video as another source; copied from {origin}, not downloaded again.')
        return True

    def _download_with_retries(self, row, options, work_root):
        with self._video_lock(row.get('video_id')):
            try:
                if self._copy_existing(row, work_root / Path(row['filename']).stem):
                    return
            except ValueError as exc:
                self.update(row, status=FAILED, phase='', progress=0, finished=time.time(), error=str(exc))
                return
            except OSError:
                pass                                # fall back to downloading it
            self._download(row, options, work_root)

    def _download(self, row, options, work_root):
        attempts = max(1, int(options.get('attempts') or 3))
        names = [options.get('provider') or 'yt-dlp']
        if names[0] != 'apify' and ApifyProvider.status()['available'] and options.get('apify_fallback'):
            names.append('apify')
        work = work_root / Path(row['filename']).stem
        work.mkdir(parents=True, exist_ok=True)
        last = None
        for name in names:
            provider = PROVIDERS[name]()
            for attempt in range(1, attempts + 1):
                if self.cancel.is_set():
                    return
                self.update(row, status=DOWNLOADING if attempt == 1 else RETRYING, attempts=row['attempts'] + 1,
                            started=row.get('started') or time.time(), error='' if attempt == 1 else row['error'],
                            phase='starting', provider=name)
                try:
                    def report(**values):
                        if row['status'] == RETRYING and values.get('downloaded_bytes'):
                            values.update(status=DOWNLOADING, error='')
                        self.update(row, **values)
                    path = Path(provider.download(row, work, options, report, self.cancel))
                    size = path.stat().st_size if path.is_file() else None
                    vid = row.get('video_id')
                    if vid in self.share and path.is_file():
                        # Another source in this sheet is the same video: keep a copy for it.
                        cache = work_root / 'shared' / (vid + '.mp4')
                        cache.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copyfile(path, cache)
                        self.shared[vid], self.titles[vid] = cache, row.get('title', '')
                    self.update(row, phase='checking', progress=99.5)
                    asset_id = self.register(row, path)
                    self.update(row, status=COMPLETED, progress=100, phase='', error='', asset_id=asset_id,
                                finished=time.time(), size=size, replace=False, note='')
                    shutil.rmtree(work, ignore_errors=True)
                    return
                except Cancelled:
                    return
                except DownloadError as exc:
                    last = exc
                    if exc.permanent:
                        break
                    if attempt < attempts:
                        delay = self.retry_delays[min(attempt - 1, len(self.retry_delays) - 1)]
                        self.update(row, status=RETRYING, phase='', error=f'{exc} Retrying in {delay}s '
                                                                          f'(attempt {attempt + 1} of {attempts}).')
                        if self.cancel._event.wait(delay):
                            return
                except ValueError as exc:            # the downloaded file was not usable
                    last = DownloadError(str(exc), permanent=True)
                    break
                except Exception as exc:              # never let one row stop the queue
                    last = DownloadError(f'Unexpected error: {exc}')
                    if attempt >= attempts:
                        break
        self.update(row, status=FAILED, phase='', progress=0, finished=time.time(),
                    error=str(last) if last else 'Download failed.')
        try:
            work.rmdir()            # only when empty: a partial download is kept for a resume
        except OSError:
            pass
