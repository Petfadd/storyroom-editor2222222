// People on screen: a photo card appears over the playing picture when the narration
// names someone. Photos are uploaded per person; timing comes from the SRT. The same
// card image is used by the monitor preview and the MP4 export.

function personOverlayData(){return P?.person_overlays||{windows:[],people:[],notes:[],settings:{}}}
function personMs(ms){const s=Math.max(0,ms/1000),m=Math.floor(s/60);return `${m}:${(s-m*60).toFixed(1).padStart(4,'0')}`}

function peopleCardHTML(){
 if(P?.edit_mode!=='documentary')return '';
 const data=personOverlayData(),conf=data.settings||{},people=P.people||[];
 const info=Object.fromEntries((data.people||[]).map(x=>[x.id,x]));
 const opt=(value,label,current)=>`<option value="${value}"${value===current?' selected':''}>${label}</option>`;
 const rows=people.map(person=>{
  const i=info[person.id]||{},photo=person.photo&&i.has_photo;
  const status=!photo?'<span class="person-status warn">No photo</span>':person.show===false?'<span class="person-status">Off</span>':`<span class="person-status ready">shown ${i.windows||0}×</span>`;
  return `<div class="person-row">
   <div class="person-thumb">${photo?`<img src="/api/projects/${P.id}/people/${person.id}/photo?v=${encodeURIComponent(person.photo.uploaded||'')}" alt="">`:'<span>No photo</span>'}</div>
   <form class="person-form" onsubmit="savePerson(event,'${person.id}')">
    <div class="person-head"><strong>${E(person.name)}</strong>${person.role?` <span class="small">${E(person.role)}</span>`:''} ${status}<span class="small"> · named ${i.mentions||0}×</span></div>
    <div class="person-fields">
     <label>Name<input name="name" value="${E(person.name)}" required></label>
     <label>Role on the card<input name="role" value="${E(person.role||'')}" placeholder="e.g. Victim, Suspect, Mother"></label>
     <label class="wide">Other spellings in the SRT <span class="small">(comma separated)</span><input name="aliases" value="${E((person.aliases||[]).join(', '))}" placeholder="e.g. Malia, Maliya"></label>
     <label class="wide">Not this person <span class="small">(phrases to ignore)</span><input name="exclude" value="${E((person.exclude||[]).join(', '))}" placeholder="e.g. Harris County"></label>
    </div>
    <p class="small">Matches: ${E((i.terms||[]).join(', '))}</p>
    <div class="inline">
     <label class="file-button">${photo?'Replace photo':'Upload photo'}<input type="file" name="photo" accept=".jpg,.jpeg,.png,.webp" onchange="savePersonForm(this.form,'${person.id}')"></label>
     <label class="check"><input type="checkbox" name="show" ${person.show===false?'':'checked'} onchange="savePersonForm(this.form,'${person.id}')"> Show photo</label>
     <label class="check"><input type="checkbox" name="short_names" ${person.short_names===false?'':'checked'} onchange="savePersonForm(this.form,'${person.id}')"> First name or surname alone counts</label>
     <button type="submit">Save</button>
     ${photo?`<button type="button" onclick="previewPersonCard('${person.id}')">See how it looks</button>`:''}
     <button type="button" onclick="removePerson('${person.id}')">Remove</button>
    </div>
   </form></div>`}).join('');
 const windows=(data.windows||[]).map(w=>`<li><button type="button" class="link" onclick="seekPersonCard(${w.start_ms})">${personMs(w.start_ms)}</button> ${E(w.name)} · ${((w.end_ms-w.start_ms)/1000).toFixed(1)}s · “${E(w.said)}” (cue ${w.cues.join(', ')})</li>`).join('');
 const notes=(data.notes||[]).map(n=>`<li>${E(n)}</li>`).join('');
 const share=data.duration_ms?` · on screen ${(data.on_screen_ms/1000).toFixed(0)}s of ${(data.duration_ms/1000/60).toFixed(1)} min${P.documentary_beat_review?'':' of narration (sound bites are added when the Beat timeline is built)'}`:'';
 return `<section class="card setup-card setup-footage people-card"><div class="setup-card-heading"><span class="setup-step">07</span><h3>People on screen</h3><span class="setup-status ${(data.windows||[]).length?'ready':''}">${(data.windows||[]).length} photo${(data.windows||[]).length===1?'':'s'} on screen${share}</span></div>
  <p>Upload a photo of the victim, suspect, family or anyone important. Whenever <strong>your narration</strong> says their name, their photo is shown ${conf.style==='card'?'as a card over the footage':'full screen'} ${conf.timing==='fixed'?`for ${(conf.hold_ms/1000)} seconds`:'for the whole SRT line that names them'}, then the footage comes back. Sound bites are never covered: they always play their own footage. Cuts and timing do not change.</p>
  <p class="small">You confirm who is in each photo and that you may use it. The editor does not check identity, source or publication rights.</p>
  <div class="inline person-settings">
   <label class="check"><input type="checkbox" ${conf.enabled===false?'':'checked'} onchange="savePersonSettings({enabled:this.checked})"> Show photos in preview and export</label>
   <label>Show photo<select onchange="savePersonSettings({style:this.value})">${opt('full','Full screen',conf.style)}${opt('card','Corner card',conf.style)}</select></label>
   <label>For<select onchange="savePersonSettings({timing:this.value})">${opt('cue','The whole SRT line',conf.timing)}${opt('fixed','A fixed time',conf.timing)}</select></label>
   ${conf.timing==='fixed'?`<label>Stays up<select onchange="savePersonSettings({hold_ms:Number(this.value)})">${[2500,3500,5000,7000].map(v=>opt(v,(v/1000)+' s',conf.hold_ms)).join('')}</select></label>`:''}
   ${conf.style==='card'?`<label>Position<select onchange="savePersonSettings({position:this.value})">${opt('right','Right',conf.position)}${opt('left','Left',conf.position)}${opt('center','Centre',conf.position)}</select></label>
   <label>Size<select onchange="savePersonSettings({size:this.value})">${opt('small','Small',conf.size)}${opt('medium','Medium',conf.size)}${opt('large','Large',conf.size)}</select></label>`:''}
   <label class="check"><input type="checkbox" ${conf.show_label===false?'':'checked'} onchange="savePersonSettings({show_label:this.checked})"> Show name and role</label>
   ${P.visual_plan_applied?`<label class="check"><input type="checkbox" ${conf.with_visual_plan?'checked':''} onchange="savePersonSettings({with_visual_plan:this.checked})"> Also show name cards with the visual plan</label>`:''}
  </div>
  ${rows||'<p class="muted">No people yet.</p>'}
  <form class="person-row person-add" onsubmit="addPerson(event)">
   <div class="person-fields">
    <label>Name as the narration says it<input name="name" required placeholder="e.g. their full name"></label>
    <label>Role on the card<input name="role" placeholder="e.g. Victim, Suspect, Mother"></label>
    <label class="wide">Other spellings in the SRT<input name="aliases" placeholder="e.g. Malia, Maliya"></label>
    <label class="wide">Photo<input type="file" name="photo" accept=".jpg,.jpeg,.png,.webp"></label>
   </div>
   <div class="inline"><button class="new" type="submit">＋ Add person</button></div>
  </form>
  ${notes?`<details open><summary>Check these (${(data.notes||[]).length})</summary><ul class="issues">${notes}</ul></details>`:''}
  ${windows?`<details><summary>Every photo on the timeline (${data.windows.length})</summary><ul class="person-windows">${windows}</ul></details>`:''}
 </section>`;
}

async function personRequest(url,method,body){
 try{P=await api(url,method,body);renderManagement();if(typeof renderProgram==='function')renderProgram();return true}
 catch(e){toast(e.message);return false}
}
function personFormData(form,id){
 const f=new FormData();if(id)f.append('id',id);
 for(const key of ['name','role','aliases','exclude']){const el=form.elements[key];if(el)f.append(key,el.value)}
 for(const key of ['show','short_names']){const el=form.elements[key];if(el)f.append(key,el.checked?'1':'0')}
 const file=form.elements.photo?.files?.[0];if(file)f.append('photo',file);
 return f;
}
async function savePerson(event,id){event.preventDefault();if(await personRequest(`/api/projects/${P.id}/people`,'POST',personFormData(event.target,id)))toast('Saved.')}
function savePersonForm(form,id){return personRequest(`/api/projects/${P.id}/people`,'POST',personFormData(form,id))}
async function addPerson(event){event.preventDefault();const form=event.target;if(!form.elements.photo.files.length&&!confirm('Add this person without a photo? No card can appear until you upload one.'))return;if(await personRequest(`/api/projects/${P.id}/people`,'POST',personFormData(form,'')))toast('Person added.')}
async function removePerson(id){const person=(P.people||[]).find(x=>x.id===id);if(!confirm(`Remove ${person?.name||'this person'} and their photo from this production?`))return;await personRequest(`/api/projects/${P.id}/people/${id}`,'DELETE')}
function savePersonSettings(change){return personRequest(`/api/projects/${P.id}`,'PATCH',{person_overlay_settings:change})}
function previewPersonCard(id){window.open(`/api/projects/${P.id}/people/${id}/card.png?v=${Date.now()}`,'_blank')}
function seekPersonCard(ms){
 if(typeof docSeekTimeline!=='function'||!window.docTimelineData?.duration){toast('Open the timeline and prepare the preview to see this card.');return}
 if($('#manage-dialog')?.open)$('#manage-dialog').close();
 docSeekTimeline(ms/1000+0.5,false);
}

// Monitor preview: the same card PNG the export uses, placed by the same geometry.
function personOverlayAt(t){
 const data=personOverlayData();if(data.settings?.enabled===false)return null;
 const ms=t*1000;return (data.windows||[]).find(w=>ms>=w.start_ms&&ms<w.end_ms)||null;
}
function updatePersonOverlay(t){
 const frame=$('#monitor-frame');if(!frame)return;
 let node=$('#person-overlay');
 if(!node){node=document.createElement('img');node.id='person-overlay';node.alt='';node.className='person-overlay';
  const captions=$('#editor-captions');frame.insertBefore(node,captions||null)}
 const w=(window.docTimelineData?.status==='ready')?personOverlayAt(t):null,g=personOverlayData().geometry;
 if(!w||!g){node.classList.remove('on');return}
 const src=`/api/projects/${P.id}/people/${w.person_id}/card.png?v=${encodeURIComponent(personOverlayData().updated||'')}`;
 if(node.dataset.src!==src){node.dataset.src=src;node.src=src}
 // The monitor frame is not always the output shape; the picture is fitted inside it
 // (letterboxed), so place the card against the fitted picture, not the frame.
 const fw=frame.clientWidth,fh=frame.clientHeight,aspect=g.aspect||16/9;
 const pw=Math.min(fw,fh*aspect),ph=pw/aspect,ox=(fw-pw)/2,oy=(fh-ph)/2;
 node.style.left=(ox+g.left*pw)+'px';node.style.top=(oy+g.top*ph)+'px';node.style.width=(g.width*pw)+'px';node.style.height=(g.height*ph)+'px';
 node.classList.add('on');
}
