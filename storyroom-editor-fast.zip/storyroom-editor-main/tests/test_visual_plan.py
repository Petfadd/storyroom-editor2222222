import tempfile, unittest
from pathlib import Path

import visual_plan as vp
from documentary_beats import read_beats


def cue(n, a, b, text):
    return {'number': n, 'start_ms': a, 'end_ms': b, 'text': text}


GUIDE = '''# Editing guide

## Project setup

- Victim: Ana Ruiz
- Suspect: Ben Cole

## Script-by-script placement

### 1. Narration beat

**At:** "On May 1"
**Show:** The railroad track seen low, no people.
**Preview:** [Report, ~0:10-0:13](https://www.youtube.com/watch?v=AAAAAAAAAA1&t=10s) (`S01`).
**Label:** News 4 | May 2024.
**Care:** The tracks only. No people.
**Source ID:** S01
**Your timing:** `00:00:00,000 --> 00:00:03,000`

### 2. Narration beat

**At:** "Police respond"
**Fill:** C / police
**Show:** No footage exists; base images cover this.
**Your timing:** `00:00:03,000 --> 00:00:06,000`

## Base clips

| Save as | What it shows | Where to get it | Tag |
|---|---|---|---|
| `BASE-C--police--01.jpg` | A police car door. | `S01` https://www.youtube.com/watch?v=AAAAAAAAAA1, frame at 0:40 | police |
| `BASE-S--portrait+2024--02.jpg` | Booking photo of Ben Cole. | `S01` https://www.youtube.com/watch?v=AAAAAAAAAA1, frame at 0:50 | portrait+2024 |
'''


class CardGuideTest(unittest.TestCase):
    def test_cards_windows_fills_and_base_table(self):
        g = vp.parse_card_guide(GUIDE)
        self.assertEqual(g['setup'], {'victim': 'Ana Ruiz', 'suspect': 'Ben Cole'})
        self.assertEqual([c['number'] for c in g['cards']], [1, 2])
        self.assertEqual(g['cards'][0]['window'], (10000, 13000))
        self.assertEqual(g['cards'][0]['year'], 2024)
        self.assertEqual(vp.parse_fill('S / court+2026 / !custody'),
                         {'category': 'S', 'tags': {'court', '2026'}, 'exclude': {'custody'}})
        self.assertEqual([(b['name'], b['at_ms'], b['category']) for b in g['base']],
                         [('BASE-C--police--01.jpg', 40000, 'C'), ('BASE-S--portrait+2024--02.jpg', 50000, 'S')])

    def test_guide_clip_is_used_and_fill_hint_finds_a_police_picture(self):
        project = {'people': [], 'assets': [{'id': 'a', 'name': 'S01.mp4', 'original_name': 'S01.mp4', 'kind': 'video',
                                             'path': 'sources/x.mp4', 'duration': 120.0}],
                   'srt': {'blocks': [cue(1, 0, 3000, 'On May 1'), cue(2, 3000, 6000, 'Police respond')]},
                   'voiceover': {'duration': 6.0}, 'production_script': {'text': GUIDE}}
        with tempfile.TemporaryDirectory() as root:
            plan = vp.plan(project, root)
        first, second = plan['rows']
        self.assertEqual((first['pieces'][0]['kind'], first['pieces'][0]['file'], first['pieces'][0]['in_ms']), ('guide', 'S01.mp4', 10000))
        self.assertIn('police', second['pieces'][0]['text'].lower())
        beats = read_beats(plan['script'])
        self.assertEqual([b['narration_in_ms'] for b in beats], [0, 3000])
        self.assertEqual(beats[-1]['narration_out_ms'], 6000)


SCRIPT = '''Beat: 001

Type: VOICE OVER

Narration clock: RESUMES at 00:00:00,000 --> 00:00:12,000

Narration state: RESUMING

Full source: S02.mp4

Source in: 00:00:00,000

Source out: 00:00:12,000

Footage audio: MUTED (0%)

Visual direction: Street outside the apartment.

On-screen caption: Houston, 2020

--------------------------------------------------------------------------------

Beat: 002

Type: DOCUMENTARY SOUND BITE

Master timeline: 00:00:12,000 --> 00:00:17,000 (Duration: 5 sec)

Narration clock: PAUSED at 00:00:12,000

Narration state: PAUSED (Suspended for duration of bite)

Speaker: Chief

Full source: S03.mp4

Source in: 00:00:00,000

Source out: 00:00:05,000

Footage audio: UNMUTED (100% Dialogue Level, Clean)

--------------------------------------------------------------------------------

Beat: 003

Type: VOICE OVER

Narration clock: RESUMES at 00:00:12,000 --> 00:00:24,000

Narration state: RESUMING

Full source: S02.mp4

Source in: 00:00:12,000

Source out: 00:00:24,000

Footage audio: MUTED (0%)

Visual direction: Courthouse.
'''

CATALOG = {'sources': {'S01': {'duration': 60.0}, 'S02': {'duration': 60.0}},
           'shots': [
               {'source': 'S01', 'in': 0, 'out': 6, 'what': 'Railroad track and ballast, no people', 'tags': ['track'], 'kind': 'place'},
               {'source': 'S01', 'in': 6, 'out': 12, 'what': 'Police car with lights at the scene', 'tags': ['police'], 'kind': 'place'},
               {'source': 'S01', 'in': 12, 'out': 18, 'what': 'Booking photo mugshot of Ben Cole', 'tags': [], 'kind': 'place'},
               {'source': 'S01', 'in': 18, 'out': 24, 'what': 'Ana Ruiz smiling at the beach, a family photo', 'tags': [], 'kind': 'place'},
               {'source': 'S01', 'in': 24, 'out': 30, 'what': 'Courtroom with the judge on the bench in 2026', 'tags': ['court'], 'kind': 'place'},
               {'source': 'S01', 'in': 30, 'out': 40, 'what': 'Apartment complex street at dusk', 'tags': ['street'], 'kind': 'place'},
           ]}


class MatcherTest(unittest.TestCase):
    def setUp(self):
        self.people = [{'id': 'v', 'name': 'Ana Ruiz', 'role': 'Victim', 'aliases': []},
                       {'id': 's', 'name': 'Ben Cole', 'role': 'Suspect', 'aliases': []}]
        self.assets = [{'id': n, 'name': n, 'original_name': n, 'kind': 'video', 'path': 'sources/' + n, 'duration': 60.0}
                       for n in ('S01.mp4', 'S02.mp4', 'S03.mp4')]

    def run_plan(self, blocks, script=SCRIPT, voice=24.0, overrides=None):
        project = {'people': self.people, 'assets': self.assets, 'srt': {'blocks': blocks}, 'voiceover': {'duration': voice},
                   'production_script': {'text': script}}
        original = vp.build_catalogue
        vp.build_catalogue = lambda p, r, g=None, b=None, broll_catalog=None: original(p, r, g, b, CATALOG)
        try:
            with tempfile.TemporaryDirectory() as root:
                return vp.plan(project, root, overrides)
        finally:
            vp.build_catalogue = original

    def pictures(self, plan):
        return [(r['text'], p['text']) for r in plan['rows'] for p in r['pieces']]

    def test_lines_get_the_shot_that_matches_them(self):
        plan = self.run_plan([cue(1, 0, 4000, 'They found her by the railroad tracks'),
                              cue(2, 4000, 8000, 'Police officers arrived within minutes'),
                              cue(3, 8000, 12000, 'Ana Ruiz was nineteen'),
                              cue(4, 12000, 18000, 'The trial was held in a Harris courtroom'),
                              cue(5, 18000, 24000, 'Ben Cole was arrested and charged')])
        got = dict(self.pictures(plan))
        self.assertIn('Railroad', got['They found her by the railroad tracks'])
        self.assertIn('Police', got['Police officers arrived within minutes'])
        self.assertIn('Ana Ruiz', got['Ana Ruiz was nineteen'])

    def test_suspect_and_mugshot_rules(self):
        plan = self.run_plan([cue(1, 0, 6000, 'Ben Cole lived nearby'),                 # named, but no arrest yet
                              cue(2, 6000, 12000, 'Ana Ruiz and her mother loved the beach'),
                              cue(3, 12000, 18000, 'Ben Cole was arrested and charged'),
                              cue(4, 18000, 24000, 'Ana Ruiz was buried in Houston')])
        for line, picture in self.pictures(plan):
            if 'mugshot' in picture.lower():
                self.assertIn('arrested', line)                  # never before the arrest is told
                self.assertNotIn('Ana Ruiz', line)              # never under a victim/family line

    def test_later_picture_never_covers_an_earlier_event(self):
        plan = self.run_plan([cue(1, 0, 12000, 'In 2020 the courtroom was empty'), cue(2, 12000, 24000, 'In 2020 again')])
        self.assertFalse(any('2026' in pic for _, pic in self.pictures(plan)))

    def test_generated_script_keeps_bites_and_reads_back(self):
        plan = self.run_plan([cue(1, 0, 4000, 'Police officers arrived'), cue(2, 4000, 12000, 'They searched the railroad tracks'),
                              cue(3, 12000, 18000, 'The apartment street was quiet'), cue(4, 18000, 24000, 'Police kept looking')])
        beats = read_beats(plan['script'])
        bites = [b for b in beats if b['kind'] != 'narration']
        self.assertEqual([(b['source_file'], b['source_in_ms'], b['source_out_ms'], b['pause_ms']) for b in bites],
                         [('S03.mp4', 0, 5000, 12000)])
        narration = [b for b in beats if b['kind'] == 'narration']
        self.assertEqual(narration[0]['narration_in_ms'], 0)
        for a, b in zip(narration, narration[1:]):
            self.assertEqual(a['narration_out_ms'], b['narration_in_ms'])
        self.assertEqual(narration[-1]['narration_out_ms'], 24000)
        for b in narration:
            self.assertGreaterEqual(b['narration_out_ms'] - b['narration_in_ms'], vp.MIN_PIECE_MS)
        windows = sorted((b['source_file'], b['source_in_ms'], b['source_out_ms']) for b in beats)
        for (f1, a1, b1), (f2, a2, b2) in zip(windows, windows[1:]):
            self.assertFalse(f1 == f2 and a2 < b1, 'no frame is used twice')

    def test_a_chosen_shot_is_kept_on_the_next_build(self):
        blocks = [cue(1, 0, 6000, 'The apartment street was quiet'), cue(2, 6000, 12000, 'Nothing else'),
                  cue(3, 12000, 24000, 'Later')]
        first = self.run_plan(blocks)
        row = first['rows'][0]
        alternatives = [a for p in row['pieces'] for a in p['alternatives']]
        self.assertTrue(alternatives)
        choice = alternatives[-1]['item']
        again = self.run_plan(blocks, overrides={str(row['start_ms']): choice})
        self.assertEqual(again['rows'][0]['pieces'][0]['item'], choice)


class FootageAndPhotoRulesTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / 'people').mkdir()
        from PIL import Image
        for n in ('ana', 'ben', 'mom', 'chief'):
            Image.new('RGB', (400, 500), (90, 90, 90)).save(self.root / 'people' / f'{n}.jpg')
        self.people = [{'id': 'v', 'name': 'Ana Ruiz', 'role': 'Victim', 'aliases': [], 'photo': {'path': 'people/ana.jpg'}},
                       {'id': 's', 'name': 'Ben Cole', 'role': 'Suspect', 'aliases': [], 'photo': {'path': 'people/ben.jpg'}},
                       {'id': 'm', 'name': 'Rosa Ruiz', 'role': 'Mother', 'aliases': [], 'photo': {'path': 'people/mom.jpg'}},
                       {'id': 'c', 'name': 'Dan Lee', 'role': 'Police chief', 'aliases': [], 'photo': {'path': 'people/chief.jpg'}}]
        self.assets = [{'id': n, 'name': n, 'original_name': n, 'kind': 'video', 'path': 'sources/' + n, 'duration': 60.0}
                       for n in ('S01.mp4', 'S02.mp4', 'S03.mp4')]

    def tearDown(self):
        self.tmp.cleanup()

    def run_plan(self, blocks, catalog=CATALOG):
        project = {'people': self.people, 'assets': self.assets, 'srt': {'blocks': blocks}, 'voiceover': {'duration': 24.0},
                   'production_script': {'text': SCRIPT}}
        original = vp.build_catalogue
        vp.build_catalogue = lambda p, r, g=None, b=None, broll_catalog=None: original(p, r, g, b, catalog)
        try:
            return vp.plan(project, self.root)
        finally:
            vp.build_catalogue = original

    def test_photos_only_for_victim_suspect_and_family_when_named(self):
        plan = self.run_plan([cue(1, 0, 4000, 'Rosa Ruiz called the police'), cue(2, 4000, 8000, 'Chief Dan Lee spoke to reporters'),
                              cue(3, 8000, 12000, 'They searched the railroad tracks'),
                              cue(4, 12000, 18000, 'Ben Cole was arrested and charged'), cue(5, 18000, 24000, 'The street was quiet')])
        photos = {r['text']: [p['file'] for p in r['pieces'] if p['kind'] == 'photo'] for r in plan['rows']}
        self.assertEqual(photos['Rosa Ruiz called the police'], ['PHOTO-Rosa_Ruiz.mp4'])          # family
        self.assertEqual(photos['Chief Dan Lee spoke to reporters'], [])                           # not victim/suspect/family
        self.assertEqual(photos['They searched the railroad tracks'], [])                         # nobody named: footage
        self.assertTrue(all(h['name'].startswith('PHOTO-') for h in plan['holds']))
        self.assertNotIn('PHOTO-Dan_Lee.mp4', [h['name'] for h in plan['holds']])

    def test_named_person_alternates_photo_and_footage_of_them(self):
        catalog = {'sources': CATALOG['sources'], 'shots': CATALOG['shots'] + [
            {'source': 'S02', 'in': 40, 'out': 50, 'what': 'Ana Ruiz dancing at a party, home video', 'tags': [], 'kind': 'people'}]}
        plan = self.run_plan([cue(1, 0, 4000, 'Ana Ruiz loved to dance'), cue(2, 4000, 8000, 'Something else entirely happened'),
                              cue(3, 8000, 12000, 'Ana Ruiz wanted to be a teacher'), cue(4, 12000, 24000, 'Later on')], catalog)
        kinds = [r['pieces'][0]['kind'] for r in plan['rows'] if 'Ana Ruiz' in r['text']]
        self.assertEqual(set(kinds), {'photo', 'match'})                                          # one of each

    def test_same_idea_keeps_the_same_shot_running(self):
        catalog = {'sources': CATALOG['sources'], 'shots': [
            {'source': 'S01', 'in': 0, 'out': 30, 'what': 'Railroad track and ballast, a long walk along the rails', 'tags': ['track'], 'kind': 'place'},
            {'source': 'S01', 'in': 30, 'out': 40, 'what': 'Police car at the scene', 'tags': ['police'], 'kind': 'place'}]}
        plan = self.run_plan([cue(1, 0, 4000, 'They walked along the railroad tracks'),
                              cue(2, 4000, 8000, 'it was a hot afternoon'), cue(3, 8000, 12000, 'and nobody saw them'),
                              cue(4, 12000, 24000, 'Police arrived later')], catalog)
        first, second, third = plan['rows'][0]['pieces'][0], plan['rows'][1]['pieces'][0], plan['rows'][2]['pieces'][0]
        self.assertEqual((second['kind'], second['file'], second['in_ms']), ('continue', first['file'], first['out_ms']))
        self.assertEqual((third['kind'], third['in_ms']), ('continue', second['out_ms']))

    def test_guide_base_pictures_are_never_frame_stills(self):
        g = vp.parse_card_guide(GUIDE)
        project = {'people': [], 'assets': [{'id': 'a', 'name': 'S01.mp4', 'original_name': 'S01.mp4', 'kind': 'video',
                                             'path': 'sources/x.mp4', 'duration': 120.0}]}
        items, _ = vp.build_catalogue(project, self.root, g, None)
        self.assertFalse([i for i in items if i['source'] == 'base_still'])
        self.assertTrue([i for i in items if i['source'] == 'base_clip' and i['moving']])

    def test_name_cards_step_aside_when_a_plan_is_applied(self):
        import person_overlays as po
        project = {'people': self.people, 'srt': {'blocks': [cue(1, 0, 3000, 'Ana Ruiz')]}, 'voiceover': {'duration': 3.0},
                   'visual_plan_applied': {'at': 1}}
        self.assertEqual(po.plan(project, self.root)['windows'], [])
        project['person_overlay_settings'] = {'with_visual_plan': True}
        self.assertEqual(len(po.plan(project, self.root)['windows']), 1)


class StillLimitTest(unittest.TestCase):
    def test_stills_stop_at_the_limit_and_say_why(self):
        planner = vp.Planner([], [], total_ms=10000, still_cap=0.10)
        still = {'id': 'x', 'moving': False, 'hold_name': 'BASE.mp4', 'available': True}
        self.assertIsNotNone(planner.take(still, 1000, 1000))
        self.assertIsNone(planner.take(still, 500, 500))
        self.assertEqual(planner.still_ms, 1000)


if __name__ == '__main__':
    unittest.main()
