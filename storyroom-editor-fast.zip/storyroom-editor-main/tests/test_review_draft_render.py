import copy,subprocess,tempfile,unittest,hashlib,json
from pathlib import Path
from unittest.mock import patch
from PIL import Image,ImageDraw
import cv2
import app as server

SCRIPT='''Shot: Srt01
Narration timeline: 00:00:00.000 --> 00:00:09.000
Exact narration: First words
Full source: Source.mp4
Source IN: 00:00:01.000
Source OUT: 00:00:10.000
Treatment: VIDEO, 1.0×, loop OFF
Visual direction: Synthetic video
Continuity: Review only
On-screen caption: On screen text
Shot: Srt02
Narration timeline: 00:00:09.000 --> 00:00:10.000
Exact narration: Last words
Photograph: Person.jpg
Shows: Test Person (victim). Identification basis: synthetic test.
Treatment: STILL — uploaded photograph, static, no motion
Visual direction: Synthetic photo
Continuity: Review only
On-screen caption: None
'''
BLOCKS=[{'number':1,'start_ms':0,'end_ms':9000,'text':'First words'},{'number':2,'start_ms':9000,'end_ms':10000,'text':'Last words'}]

class ReviewDraftRenderTest(unittest.TestCase):
 def test_complete_strict_review_renders_without_unblocking_final(self):
  with tempfile.TemporaryDirectory() as tmp,patch.object(server,'PROJECTS',Path(tmp)):
   c=server.app.test_client();pid=c.post('/api/projects',json={'title':'Test','picture_policy':'mixed','size':'320x180'}).get_json()['id'];root=Path(tmp)/pid;p=server.load(pid);p['srt']={'name':'test.srt','blocks':copy.deepcopy(BLOCKS)};p['production_script']={'name':'test.txt','text':SCRIPT};(root/'inputs/captions.srt').write_text('1\n00:00:00,000 --> 00:00:09,000\nFirst words\n\n2\n00:00:09,000 --> 00:00:10,000\nLast words\n')
   ff=server.FFMPEG
   subprocess.run([ff,'-loglevel','error','-y','-f','lavfi','-i','testsrc2=s=320x180:r=30:d=12','-c:v','libx264','-pix_fmt','yuv420p',str(root/'sources/video.mp4')],check=True)
   subprocess.run([ff,'-loglevel','error','-y','-f','lavfi','-i','sine=frequency=440:duration=10','-c:a','libmp3lame',str(root/'inputs/voiceover.mp3')],check=True);photo=Image.new('RGB',(120,80),(220,10,10));ImageDraw.Draw(photo).rectangle((24,16,95,65),fill=(10,90,180));photo.save(root/'assets/photo.jpg')
   p['voiceover']={'name':'fixture.mp3','duration':10,'path':'inputs/voiceover.mp3'};p['assets']=[{'id':'v','name':'Source.mp4','original_name':'Source.mp4','path':'sources/video.mp4','kind':'video','duration':12,'source':'synthetic','people':[],'category':'general','verified':True,'rights':'unreviewed','notes':''},{'id':'i','name':'Person.jpg','original_name':'Person.jpg','path':'assets/photo.jpg','kind':'image','duration':0,'source':'synthetic','people':['Test Person'],'category':'person','verified':True,'rights':'unreviewed','notes':''}];server.save(p)
   res=c.post(f'/api/projects/{pid}/script-draft',json={'moving_only':True,'require_ready':True});self.assertEqual(res.status_code,200,res.get_data(as_text=True));p=server.load(pid)
   for s in p['scenes']:s['approved']=True
   server.save(p);self.assertTrue(server.check(p)['can_export']);self.assertFalse(server.check(p,True)['can_export'])
   broken=copy.deepcopy(p);broken['scenes'][0]['asset_id']=None;self.assertFalse(server.check(broken)['can_export'])
   broken=copy.deepcopy(p);broken['voiceover']['duration']=10.2;self.assertTrue(any('must not trim' in e for e in server.check(broken)['errors']))
   self.assertEqual(c.post(f'/api/projects/{pid}/render',json={'final':False}).status_code,400)
   res=c.post(f'/api/projects/{pid}/render',json={'strict_checked_version':server.load(pid)['updated'],'final':False});self.assertEqual(res.status_code,202,res.get_data(as_text=True));job=server.JOBS[pid];job.worker_thread.join(timeout=90);state=job.snapshot();self.assertEqual(state['status'],'done',state)
   cap=cv2.VideoCapture(str(root/'renders'/state['output']));count=int(cap.get(cv2.CAP_PROP_FRAME_COUNT));fps=cap.get(cv2.CAP_PROP_FPS);cap.set(cv2.CAP_PROP_POS_FRAMES,30);ok,clean=cap.read();cap.release();self.assertTrue(ok);self.assertEqual((count,fps),(300,30));self.assertFalse(state['captions']);self.assertEqual(c.get(f'/api/projects/{pid}').get_json()['render']['options'],{'script_captions':False,'srt_subtitles':False,'enhance_picture':False})
   original_video=hashlib.sha256((root/'sources/video.mp4').read_bytes()).hexdigest();original_photo=hashlib.sha256((root/'assets/photo.jpg').read_bytes()).hexdigest()
   cap=cv2.VideoCapture(str(root/'renders'/state['output']));cap.set(cv2.CAP_PROP_POS_FRAMES,280);ok,clean_photo=cap.read();cap.release();self.assertTrue(ok)
   res=c.post(f'/api/projects/{pid}/render',json={'strict_checked_version':server.load(pid)['updated'],'final':False,'enhance_picture':True});self.assertEqual(res.status_code,202,res.get_data(as_text=True));job=server.JOBS[pid];job.worker_thread.join(timeout=90);enhanced=job.snapshot();self.assertEqual(enhanced['status'],'done',enhanced);self.assertTrue(enhanced['picture_enhancement'])
   cap=cv2.VideoCapture(str(root/'renders'/enhanced['output']));self.assertEqual(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)),300);cap.set(cv2.CAP_PROP_POS_FRAMES,30);ok,enhanced_video=cap.read();self.assertTrue(ok);cap.set(cv2.CAP_PROP_POS_FRAMES,280);ok,enhanced_photo=cap.read();cap.release();self.assertTrue(ok)
   self.assertGreater(float(abs(clean.astype('float32')-enhanced_video.astype('float32')).mean()),.05);self.assertGreater(float(abs(clean_photo.astype('float32')-enhanced_photo.astype('float32')).mean()),.05)
   self.assertEqual(original_video,hashlib.sha256((root/'sources/video.mp4').read_bytes()).hexdigest());self.assertEqual(original_photo,hashlib.sha256((root/'assets/photo.jpg').read_bytes()).hexdigest());self.assertTrue(json.loads((root/'reviews'/(Path(enhanced['output']).stem+'.json')).read_text())['picture_enhancement']);self.assertTrue(c.get(f'/api/projects/{pid}').get_json()['render']['options']['enhance_picture'])
   res=c.post(f'/api/projects/{pid}/render',json={'strict_checked_version':server.load(pid)['updated'],'final':False,'srt_subtitles':True});self.assertEqual(res.status_code,202,res.get_data(as_text=True));job=server.JOBS[pid];job.worker_thread.join(timeout=90);state=job.snapshot();self.assertEqual(state['status'],'done',state)
   cap=cv2.VideoCapture(str(root/'renders'/state['output']));cap.set(cv2.CAP_PROP_POS_FRAMES,30);ok,srt_frame=cap.read();cap.release();self.assertTrue(ok);self.assertGreater(float(abs(clean.astype('float32')-srt_frame.astype('float32')).mean()),0.05);self.assertTrue(state['captions']);self.assertEqual((root/'renders'/state['output']).with_suffix('.srt').read_text(),(root/'inputs/captions.srt').read_text())
   res=c.post(f'/api/projects/{pid}/render',json={'strict_checked_version':server.load(pid)['updated'],'final':False,'script_captions':True});self.assertEqual(res.status_code,202,res.get_data(as_text=True));job=server.JOBS[pid];job.worker_thread.join(timeout=90);state=job.snapshot();self.assertEqual(state['status'],'done',state)
   cap=cv2.VideoCapture(str(root/'renders'/state['output']));cap.set(cv2.CAP_PROP_POS_FRAMES,30);ok,burned=cap.read();cap.release();self.assertTrue(ok);self.assertGreater(float(abs(clean.astype('float32')-burned.astype('float32')).mean()),0.05);self.assertTrue(state['captions']);self.assertEqual((root/'renders'/state['output']).with_suffix('.srt').read_text(),(root/'inputs/captions.srt').read_text())
   display=(root/'reviews'/(Path(state['output']).stem+'_script_captions.srt')).read_text();self.assertIn('On screen text',display);self.assertNotIn('Review only',display);self.assertNotIn('None',display)

   for invalid in (99,201,True,105.5,'105'):
    self.assertEqual(c.patch(f'/api/projects/{pid}',json={'picture_scale':invalid}).status_code,400)
   before=server.load(pid);res=c.patch(f'/api/projects/{pid}',json={'picture_scale':150});self.assertEqual(res.status_code,200);after=server.load(pid);self.assertEqual(after['picture_scale'],150);self.assertEqual(before['scenes'],after['scenes'])
   res=c.post(f'/api/projects/{pid}/render',json={'strict_checked_version':server.load(pid)['updated'],'final':False});self.assertEqual(res.status_code,202,res.get_data(as_text=True));job=server.JOBS[pid];job.worker_thread.join(timeout=90);state=job.snapshot();self.assertEqual(state['status'],'done',state)
   cap=cv2.VideoCapture(str(root/'renders'/state['output']));self.assertEqual(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)),300);cap.set(cv2.CAP_PROP_POS_FRAMES,30);ok,scaled=cap.read();cap.release();self.assertTrue(ok);self.assertGreater(float(abs(clean.astype('float32')-scaled.astype('float32')).mean()),2)

   cap=cv2.VideoCapture(str(root/'renders'/state['output']));cap.set(cv2.CAP_PROP_POS_FRAMES,280);ok,photo_before=cap.read();cap.release();self.assertTrue(ok)
   sid=after['scenes'][0]['id'];scene_url=f'/api/projects/{pid}/scenes/{sid}/picture-scale'
   for invalid in (99,201,True,105.5,'105'):
    self.assertEqual(c.patch(scene_url,json={'picture_scale':invalid}).status_code,400)
   res=c.patch(scene_url,json={'picture_scale':100});self.assertEqual(res.status_code,200);updated=server.load(pid);self.assertEqual(updated['scenes'][0]['picture_scale'],100);self.assertEqual(updated['scenes'][1],after['scenes'][1]);self.assertEqual(updated['scenes'][0]['in_s'],after['scenes'][0]['in_s']);self.assertEqual(updated['scenes'][0]['approved'],after['scenes'][0]['approved'])
   res=c.post(f'/api/projects/{pid}/render',json={'strict_checked_version':server.load(pid)['updated'],'final':False});self.assertEqual(res.status_code,202);job=server.JOBS[pid];job.worker_thread.join(timeout=90);state=job.snapshot();self.assertEqual(state['status'],'done',state)
   cap=cv2.VideoCapture(str(root/'renders'/state['output']));self.assertEqual(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)),300);cap.set(cv2.CAP_PROP_POS_FRAMES,30);ok,slot=cap.read();self.assertTrue(ok);cap.set(cv2.CAP_PROP_POS_FRAMES,280);ok,photo_after=cap.read();cap.release();self.assertTrue(ok);self.assertLess(float(abs(clean.astype('float32')-slot.astype('float32')).mean()),0.2);self.assertLess(float(abs(photo_before.astype('float32')-photo_after.astype('float32')).mean()),0.2)
   self.assertEqual(c.patch(scene_url,json={'picture_scale':None}).status_code,200);self.assertNotIn('picture_scale',server.load(pid)['scenes'][0])

   bulk=f'/api/projects/{pid}/scenes/picture-scale';ids=[s['id'] for s in server.load(pid)['scenes']];snapshot=server.load(pid)
   for body in ({'scene_ids':ids+['missing'],'picture_scale':120},{'scene_ids':ids+ids,'picture_scale':120},{'scene_ids':ids,'picture_scale':201},{'scene_ids':[],'picture_scale':120}):
    self.assertEqual(c.patch(bulk,json=body).status_code,400);self.assertEqual(server.load(pid),snapshot)
   self.assertEqual(c.patch(bulk,json={'scene_ids':ids,'picture_scale':125}).status_code,200);updated=server.load(pid);self.assertEqual([s['picture_scale'] for s in updated['scenes']],[125,125]);self.assertEqual(updated['picture_scale'],150)
   res=c.post(f'/api/projects/{pid}/render',json={'strict_checked_version':updated['updated'],'final':False,'script_captions':True,'srt_subtitles':True,'enhance_picture':True});self.assertEqual(res.status_code,202,res.get_data(as_text=True));job=server.JOBS[pid];job.worker_thread.join(timeout=90);combined=job.snapshot();self.assertEqual(combined['status'],'done',combined)
   cap=cv2.VideoCapture(str(root/'renders'/combined['output']));self.assertEqual(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)),300);cap.set(cv2.CAP_PROP_POS_FRAMES,30);ok,combined_video=cap.read();self.assertTrue(ok);cap.set(cv2.CAP_PROP_POS_FRAMES,280);ok,combined_photo=cap.read();cap.release();self.assertTrue(ok);self.assertGreater(float(abs(clean.astype('float32')-combined_video.astype('float32')).mean()),2);self.assertGreater(float(abs(clean_photo.astype('float32')-combined_photo.astype('float32')).mean()),.1)
   public=c.get(f'/api/projects/{pid}').get_json();self.assertEqual(public['render']['options'],{'script_captions':True,'srt_subtitles':True,'enhance_picture':True});manifest=json.loads((root/'storyboard.json').read_text());self.assertEqual([s['picture_scale'] for s in manifest['shots']],[125,125]);self.assertEqual((root/'renders'/combined['output']).with_suffix('.srt').read_text(),(root/'inputs/captions.srt').read_text())
   self.assertEqual(c.patch(bulk,json={'scene_ids':[ids[0]],'picture_scale':None}).status_code,200);updated=server.load(pid);self.assertNotIn('picture_scale',updated['scenes'][0]);self.assertEqual(updated['scenes'][1]['picture_scale'],125)
